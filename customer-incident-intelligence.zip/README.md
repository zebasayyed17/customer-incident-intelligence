# Customer Incident Intelligence

> **An end-to-end NLP analytics platform for discovering recurring customer issues, understanding sentiment, and monitoring changes over time.**

**Portfolio project for data science / analytics students**

Customer Incident Intelligence turns unstructured customer complaints, reviews, and support tickets into an inspectable analytics workflow. The system is designed to work with **new datasets without requiring the user to manually map columns or define issue categories first**.

```text
CSV / XLSX / XLSM / XLS
        |
        v
Automatic schema detection
(text / date / evaluation fields)
        |
        v
Text cleaning + validation
        |
        v
MiniLM sentence embeddings
384-dimensional semantic vectors
        |
        v
Adaptive unsupervised clustering
        |
        +--------------------+
        |                    |
        v                    v
Issue discovery       Sentiment analysis
                      RoBERTa 3-class
        |                    |
        +---------+----------+
                  |
                  v
        Date-aware analytics
          (when dates exist)
                  |
          baseline comparison
          + lift + z-score
                  |
                  v
             Surge alerts
                  |
                  v
        FastAPI + Web Dashboard
```

## What this project demonstrates

This project is intentionally broader than a single notebook or classifier. It demonstrates a complete applied data-science workflow:

- **Data ingestion:** CSV, XLSX, XLSM and XLS support.
- **Automatic schema detection:** identifies useful text, date/time and evaluation fields.
- **NLP representation:** converts customer text into 384-dimensional MiniLM embeddings.
- **Unsupervised discovery:** groups semantically related records without requiring predefined issue labels.
- **Interpretation:** extracts issue/topic phrases and representative examples for cluster inspection.
- **Sentiment analysis:** predicts Positive, Neutral or Negative sentiment with a pretrained RoBERTa classifier.
- **Temporal analytics:** compares recent issue volume with a historical baseline when a usable date field exists.
- **Statistical alerting:** uses frequency, lift and z-score signals to flag unusual increases.
- **API + UI:** exposes the workflow through FastAPI and a lightweight HTML/CSS/JavaScript interface.
- **GPU acceleration:** uses PyTorch/CUDA when available, with CPU fallback.
- **Benchmark discipline:** keeps BANKING77 as a reference benchmark instead of forcing arbitrary datasets into banking-specific labels.

## Why the architecture uses separate models

The project separates four different analytical questions:

| Question | Component |
|---|---|
| What does each piece of text mean? | `sentence-transformers/all-MiniLM-L6-v2` |
| Which records describe related problems? | Unsupervised semantic clustering |
| What sentiment is expressed? | `j-hartmann/sentiment-roberta-large-english-3-classes` |
| Is an issue changing unusually over time? | Baseline + lift + z-score trend logic |

This separation makes the pipeline easier to explain, test, and adapt to new domains.

## Core models and methods

### 1. Semantic embeddings

`all-MiniLM-L6-v2` converts each text record into a **384-dimensional embedding**. Similar meanings can then be compared in vector space instead of relying only on exact keywords.

### 2. Unsupervised issue discovery

The clustering layer is designed for discovery. The uploaded dataset forms its own semantic space, so the application does not assume that a new dataset belongs to BANKING77 or any other fixed taxonomy.

During development, BANKING77 cluster experiments were evaluated with **NMI, ARI, purity and coverage**. Labels were excluded from cluster formation and used only after clustering for diagnostics.

### 3. Sentiment

The current sentiment model is:

`j-hartmann/sentiment-roberta-large-english-3-classes`

The output is Positive / Neutral / Negative with a model confidence score.

### 4. Trend monitoring

When a reliable date column exists, issue counts can be aggregated over time and compared with a historical baseline. The alert layer uses configured count, lift and z-score thresholds.

These are **operational signals**, not causal diagnoses or claims about the prevalence of an issue in the wider population.

## Dataset-independent behavior

A major design goal is that the application should still be useful when the next dataset looks completely different from the benchmark.

For example:

```text
Banking complaints        -> banking-related issue clusters
Product reviews           -> product / quality / delivery clusters
Support tickets           -> technical / account / billing clusters
Custom student dataset    -> clusters discovered from that dataset
```

The system does not require the user to manually choose a text column before every run. It attempts to infer the most useful fields automatically.

## Benchmark / example datasets

The repository includes example inputs under `benchmark/`:

### Customer Reviews 10,000

Used to test:

- automatic text-field detection
- semantic embeddings
- unsupervised issue discovery
- sentiment analysis
- rating/evaluation-field detection

This dataset does not provide a reliable date/time field, so temporal monitoring is correctly treated as unavailable for this input.

### Lingrow Support Tickets

Used to test:

- text + date ingestion
- semantic discovery
- sentiment analysis
- temporal aggregation
- surge / alert logic

The support-ticket dataset is synthetic and should be treated as a technical benchmark, not real production evidence.

### BANKING77

BANKING77 is the known-label reference benchmark used during development for semantic diagnostics and clustering evaluation. Arbitrary datasets are **not** forced into its 77-intent taxonomy.

## Project architecture

```text
customer-incident-intelligence/
├── backend/app/                 # FastAPI application + Web UI
│   ├── ml/                      # Embedding and sentiment services
│   ├── api/                     # API package
│   └── static/                  # HTML / CSS / JavaScript
├── scripts/                     # Data, benchmark and analysis utilities
├── benchmark/                   # Example datasets and benchmark notes
├── data/                        # Runtime/generated files (mostly gitignored)
├── docs/                        # Architecture, portfolio and interview notes
├── install/                     # Standalone Windows installer
├── tests/                       # Test area
├── .github/workflows/           # CI syntax checks
├── requirements.txt
└── setup_windows.ps1
```

## Quick start — Windows

### One-file installer

```powershell
Set-ExecutionPolicy -Scope Process Bypass
.\install\Install_Customer_Incident_Intelligence.ps1
```

### Manual setup

```powershell
cd C:\customer-incident-intelligence
Set-ExecutionPolicy -Scope Process Bypass
.\setup_windows.ps1
.\.venv\Scripts\python.exe scripts\verify_environment.py
.\scripts\run_webui.ps1
```

Open:

```text
http://127.0.0.1:8000/
```

FastAPI documentation:

```text
http://127.0.0.1:8000/docs
```

## Using the Dataset Lab

1. Drop a supported dataset into the application.
2. The application detects the most useful fields automatically.
3. Analysis starts automatically.
4. Progress is shown while the pipeline runs.
5. The dashboard presents issue discovery, sentiment and any available trend results.
6. Click a discovered cluster to inspect representative records.

A descriptive text field is required. A date field is optional. Without a date, issue discovery and sentiment still work; temporal monitoring is marked as unavailable rather than treated as a pipeline failure.

## Portfolio / interview talking points

### 30-second explanation

> Customer Incident Intelligence is an end-to-end NLP analytics platform that accepts customer complaints, reviews, or support tickets, automatically detects useful fields, converts text into MiniLM embeddings, discovers recurring issue groups with unsupervised clustering, predicts sentiment with a pretrained RoBERTa model, and—when dates exist—compares issue volume with a historical baseline to surface statistical surge signals. FastAPI exposes the workflow through a lightweight dashboard.

### The main data-science concepts demonstrated

- vector representations / embeddings
- semantic similarity
- unsupervised learning
- clustering diagnostics
- text classification
- feature and schema inference
- time-series aggregation
- baseline comparison
- anomaly / surge detection
- model inference on GPU
- evaluation design and leakage awareness
- end-to-end data product delivery

## Evaluation notes

The BANKING77 workflow includes explicit data-quality and leakage checks. Seven exact text overlaps were found between the official train/test files during development, so a leakage-aware evaluation set was prepared before downstream diagnostics were interpreted.

The unsupervised clustering metrics are used as **diagnostics**, not as classification accuracy. A custom unlabeled dataset cannot support a supervised accuracy claim without an appropriate reference label set.

## Important limitations

- The system performs **issue discovery and monitoring**, not causal root-cause analysis.
- Cluster names are interpretations of discovered groups, not ground truth.
- An unlabeled custom dataset cannot support ordinary supervised accuracy metrics.
- A dataset without a reliable date field cannot support time-based trend claims.
- Public/benchmark complaint data should not be treated as a statistical sample of all customer experiences.
- Pretrained sentiment output should be treated as an analytical signal unless it has been validated on a domain-appropriate labeled set.

## Documentation

- [Architecture](docs/ARCHITECTURE.md) — runtime components and design decisions
- [Installation](docs/INSTALLATION.md) — Windows installation and troubleshooting
- [Portfolio](docs/PORTFOLIO.md) — resume / LinkedIn / portfolio framing
- [Interview Guide](docs/INTERVIEW_GUIDE.md) — concise technical explanations and interview questions
- [Benchmark Notes](benchmark/README.md) — example dataset roles and limitations

## Engineering notes

The core path deliberately avoids a generative LLM. The project uses pretrained embedding/classification models plus classical and unsupervised analytics so that the main data-science reasoning remains explicit and inspectable.

The repository also includes a lightweight GitHub Actions workflow that compiles the Python source tree as a syntax check.

## License

No open-source license is currently declared. Add the license you intend to use before accepting external contributions.
