from __future__ import annotations

import copy
import csv
import json
import math
import re
import threading
import uuid
from concurrent.futures import ThreadPoolExecutor
from functools import lru_cache
from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd
import torch
from fastapi import FastAPI, File, HTTPException, UploadFile
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel, Field
from sentence_transformers import SentenceTransformer
from sklearn.cluster import MiniBatchKMeans
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.preprocessing import normalize
from transformers import pipeline

ROOT = Path(__file__).resolve().parents[2]
PROCESSED = ROOT / "data" / "processed"
REPORTS = ROOT / "data" / "reports"
UPLOADS = ROOT / "data" / "uploads"
RUNTIME = ROOT / "data" / "runtime"
STATIC = Path(__file__).resolve().parent / "static"
INDEX_HTML = STATIC / "index.html"
ACTIVE_DATASET_PATH = RUNTIME / "active_dataset.json"

for directory in (UPLOADS, RUNTIME, STATIC):
    directory.mkdir(parents=True, exist_ok=True)

MAX_UPLOAD_BYTES = 25 * 1024 * 1024
# This is an interactive safety limit, not a dataset-size requirement. For larger files,
# basic file statistics are retained and a transparent ML sample is analyzed.
MAX_ML_ROWS = 20_000
MIN_CLUSTER_ROWS = 24
MAX_CLUSTERS = 48
PREVIEW_ROWS = 8

app = FastAPI(
    title="Customer Incident Intelligence",
    version="0.5.0",
    description="Dataset-independent customer incident intelligence with semantic discovery, sentiment, and optional temporal monitoring.",
)
app.mount("/static", StaticFiles(directory=str(STATIC)), name="static")


class AnalyzeRequest(BaseModel):
    text: str = Field(min_length=3, max_length=4000)


class AnalyzeResponse(BaseModel):
    text: str
    sentiment: str
    sentiment_confidence: float
    semantic_target: str
    semantic_target_type: str
    semantic_similarity: float
    nearest_intent: str
    nearest_intent_similarity: float
    dataset: str


BENCHMARK_DATASET: dict[str, Any] = {
    "id": "banking77",
    "name": "BANKING77",
    "kind": "builtin",
    "rows": 10003,
    "source_rows": 10003,
    "rows_analyzed": 10003,
    "text_column": "text",
    "date_column": None,
    "label_column": "category",
    "detected_columns": ["text", "category"],
    "sentiment": {"positive": 0, "neutral": 0, "negative": 0},
    "sentiment_percent": {"positive": 0.0, "neutral": 0.0, "negative": 0.0},
    "clusters": [],
    "cluster_centroids": {},
    "records": [],
    "trend_rows": [],
    "alerts": [],
    "alert_summary": {"date_available": False},
    "notes": [
        "Benchmark mode: BANKING77 has known intent labels and precomputed issue discovery outputs.",
    ],
}

CURRENT_DATASET: dict[str, Any] = copy.deepcopy(BENCHMARK_DATASET)
PENDING_UPLOADS: dict[str, dict[str, Any]] = {}
ANALYSIS_JOBS: dict[str, dict[str, Any]] = {}
ANALYSIS_EXECUTOR = ThreadPoolExecutor(max_workers=1, thread_name_prefix="cii-analysis")
DATASET_LOCK = threading.RLock()


def load_json(path: Path) -> dict[str, Any]:
    if not path.exists():
        return {}
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except Exception:
        return {}


def save_active_dataset() -> None:
    if CURRENT_DATASET.get("kind") != "upload":
        ACTIVE_DATASET_PATH.unlink(missing_ok=True)
        return
    ACTIVE_DATASET_PATH.write_text(
        json.dumps(CURRENT_DATASET, ensure_ascii=False),
        encoding="utf-8",
    )


def restore_active_dataset() -> None:
    global CURRENT_DATASET
    payload = load_json(ACTIVE_DATASET_PATH)
    if payload.get("kind") == "upload" and payload.get("clusters"):
        CURRENT_DATASET = payload


restore_active_dataset()


def read_csv_rows(path: Path) -> list[dict[str, str]]:
    if not path.exists():
        return []
    with path.open("r", encoding="utf-8", newline="") as f:
        return list(csv.DictReader(f))


@lru_cache(maxsize=1)
def embedding_model() -> SentenceTransformer:
    device = "cuda" if torch.cuda.is_available() else "cpu"
    return SentenceTransformer("sentence-transformers/all-MiniLM-L6-v2", device=device)


@lru_cache(maxsize=1)
def sentiment_model():
    device = 0 if torch.cuda.is_available() else -1
    return pipeline(
        "text-classification",
        model="j-hartmann/sentiment-roberta-large-english-3-classes",
        tokenizer="j-hartmann/sentiment-roberta-large-english-3-classes",
        device=device,
    )


@lru_cache(maxsize=1)
def intent_index() -> tuple[np.ndarray, list[str]]:
    emb_path = PROCESSED / "train_embeddings.npy"
    labels_path = PROCESSED / "train_labels.json"
    if not emb_path.exists() or not labels_path.exists():
        raise FileNotFoundError("BANKING77 embeddings/labels are missing. Complete Brick 4 first.")
    X = np.load(emb_path).astype(np.float32)
    labels = json.loads(labels_path.read_text(encoding="utf-8"))
    unique_labels = sorted(set(labels))
    label_arr = np.array(labels)
    centroids = []
    for label in unique_labels:
        centroids.append(X[label_arr == label].mean(axis=0))
    return normalize(np.asarray(centroids, dtype=np.float32)), unique_labels


def sentiment_label(raw_label: str) -> str:
    label = str(raw_label).lower()
    if "positive" in label:
        return "positive"
    if "negative" in label:
        return "negative"
    if "neutral" in label:
        return "neutral"
    return label


def _normalized_name(name: str) -> str:
    return re.sub(r"[^a-z0-9]+", "", str(name).strip().lower())


def detect_columns(df: pd.DataFrame) -> dict[str, Any]:
    """Autonomously detect useful semantic, date, and evaluation fields."""
    columns = [str(c) for c in df.columns]
    normalized = {c: _normalized_name(c) for c in columns}

    text_terms = (
        "text", "review", "reviewtext", "comment", "complaint", "description", "feedback",
        "message", "narrative", "issue", "body", "content", "details", "reason", "remark",
    )
    date_terms = (
        "date", "datetime", "timestamp", "time", "created", "received", "submitted", "occurred",
        "opened", "closed", "posted", "purchase", "orderdate", "createdat", "updatedat",
    )
    label_terms = (
        "label", "class", "category", "intent", "topic", "sentiment", "issue", "rating", "score",
        "stars", "target", "outcome", "resolution",
    )
    id_terms = ("id", "uuid", "guid", "number", "code", "key")

    def name_score(name: str, terms: tuple[str, ...]) -> int:
        n = normalized[name]
        total = 0
        for term in terms:
            if n == term:
                total += 10
            elif n.startswith(term) or n.endswith(term):
                total += 5
            elif term in n:
                total += 2
        return total

    def text_quality(col: str) -> float:
        s = df[col].fillna("").astype(str)
        if len(s) == 0:
            return 0.0
        lengths = s.str.len()
        nonempty = float((lengths >= 3).mean())
        avg_len = float(lengths.mean())
        uniqueness = float(s.nunique(dropna=True) / max(len(s), 1))
        return nonempty * min(avg_len / 120.0, 1.0) * (0.5 + min(uniqueness, 1.0) * 0.5)

    candidates = []
    for c in columns:
        if pd.api.types.is_numeric_dtype(df[c]) and name_score(c, text_terms) == 0:
            continue
        score = name_score(c, text_terms) * 5 + text_quality(c) * 10
        if score > 0:
            candidates.append((score, c))
    if candidates:
        text_col = max(candidates)[1]
    else:
        object_cols = [c for c in columns if not pd.api.types.is_numeric_dtype(df[c])]
        text_col = max(object_cols, key=text_quality) if object_cols else (columns[0] if columns else None)

    date_col = None
    date_candidates = []
    for c in columns:
        if c == text_col:
            continue
        s = df[c]
        parsed = pd.to_datetime(s, errors="coerce")
        valid_ratio = float(parsed.notna().mean()) if len(s) else 0.0
        if valid_ratio >= 0.65:
            score = name_score(c, date_terms) * 5 + valid_ratio * 5
            if not pd.api.types.is_numeric_dtype(s) or name_score(c, date_terms) > 0:
                date_candidates.append((score, c, valid_ratio))
    if date_candidates:
        date_col = max(date_candidates)[1]

    label_col = None
    label_candidates = []
    for c in columns:
        if c in {text_col, date_col}:
            continue
        s = df[c]
        nunique = int(s.nunique(dropna=True))
        ratio = nunique / max(len(df), 1)
        score = name_score(c, label_terms) * 5
        if "rating" in normalized[c] or "score" in normalized[c] or "stars" in normalized[c]:
            score += 10
        # Prefer useful categorical/ordinal fields, never identifier-like high-cardinality fields.
        if nunique >= 2 and ratio <= 0.25:
            score += 5
        if name_score(c, id_terms) > 0 and ratio > 0.25:
            score -= 15
        if score > 0 and nunique >= 2:
            label_candidates.append((score, c, nunique))
    if label_candidates:
        label_col = max(label_candidates)[1]

    return {
        "columns": columns,
        "text_column": text_col,
        "date_column": date_col,
        "label_column": label_col,
        "row_count": int(len(df)),
    }


def read_uploaded_dataframe(path: Path) -> pd.DataFrame:
    suffix = path.suffix.lower()
    if suffix == ".csv":
        return pd.read_csv(path, low_memory=False)
    if suffix in {".xlsx", ".xlsm", ".xls"}:
        return pd.read_excel(path)
    raise ValueError("Only CSV, XLSX, XLSM, and XLS files are supported.")


def choose_cluster_count(n: int) -> int:
    """Choose K automatically from sample size with a transparent safety ceiling."""
    if n < MIN_CLUSTER_ROWS:
        return 1
    target = max(4, int(round(math.sqrt(n))))
    upper = min(MAX_CLUSTERS, max(4, n // MIN_CLUSTER_ROWS))
    return max(4, min(target, upper))


def make_cluster_label(texts: list[str]) -> tuple[str, list[str]]:
    if not texts:
        return "Unlabelled cluster", []
    try:
        vectorizer = TfidfVectorizer(
            stop_words="english",
            ngram_range=(1, 2),
            min_df=max(1, min(3, max(1, len(texts) // 10))),
            max_features=80,
        )
        matrix = vectorizer.fit_transform(texts)
        scores = np.asarray(matrix.mean(axis=0)).ravel()
        terms = np.asarray(vectorizer.get_feature_names_out())
        order = scores.argsort()[::-1]
        keywords = [str(terms[i]) for i in order[:8] if scores[i] > 0]
    except Exception:
        keywords = []
    label = " + ".join(keywords[:3]) if keywords else "Emerging customer issue"
    return label.title(), keywords


def build_alerts(dates: pd.Series, assignments: np.ndarray, cluster_map: dict[int, dict[str, Any]]) -> tuple[list[dict[str, Any]], dict[str, Any]]:
    parsed = pd.to_datetime(dates, errors="coerce")
    valid = parsed.notna()
    if not valid.any():
        return [], {"date_available": False}

    dated = pd.DataFrame({
        "date": parsed.loc[valid].dt.normalize().reset_index(drop=True),
        "cluster_id": assignments[valid.to_numpy()],
    })
    min_date = dated["date"].min()
    max_date = dated["date"].max()
    span_days = int((max_date - min_date).days) + 1
    if span_days < 14:
        return [], {
            "date_available": True,
            "start_date": str(min_date.date()),
            "end_date": str(max_date.date()),
            "span_days": span_days,
            "alert_note": "The date field is usable, but at least 14 days are needed for a current-vs-baseline alert window.",
        }

    current_days = 7
    baseline_days = min(28, span_days - current_days)
    if baseline_days < 7:
        return [], {
            "date_available": True,
            "start_date": str(min_date.date()),
            "end_date": str(max_date.date()),
            "span_days": span_days,
            "alert_note": "The date field is usable, but there is not enough baseline history for a formal alert.",
        }

    current_start = max_date - pd.Timedelta(days=current_days - 1)
    baseline_end = current_start - pd.Timedelta(days=1)
    baseline_start = baseline_end - pd.Timedelta(days=baseline_days - 1)
    baseline = dated[(dated["date"] >= baseline_start) & (dated["date"] <= baseline_end)]
    current = dated[dated["date"] >= current_start]

    base_counts = baseline.groupby("cluster_id").size().to_dict()
    current_counts = current.groupby("cluster_id").size().to_dict()
    alerts: list[dict[str, Any]] = []
    for cluster_id, current_count in current_counts.items():
        baseline_count = int(base_counts.get(cluster_id, 0))
        expected = baseline_count * (current_days / baseline_days)
        if expected <= 0:
            # A genuinely new issue in the current window is noteworthy, but avoid calling every
            # one-row cluster an alert. Require at least five current rows.
            if current_count >= 8:
                cluster = cluster_map.get(int(cluster_id), {})
                alerts.append({
                    "cluster_id": int(cluster_id),
                    "issue": cluster.get("label", f"Cluster {cluster_id}"),
                    "product": "Dataset-local semantic issue",
                    "current_count": int(current_count),
                    "expected_count": 0.0,
                    "absolute_change": int(current_count),
                    "lift": None,
                    "z_score": None,
                    "alert": True,
                    "alert_reason": "New activity in the current window",
                    "current_window_days": current_days,
                    "baseline_window_days": baseline_days,
                })
            continue
        lift = current_count / expected
        z_score = (current_count - expected) / math.sqrt(max(expected, 1.0))
        if current_count >= 5 and expected >= 3 and lift >= 1.5 and z_score >= 2.0:
            cluster = cluster_map.get(int(cluster_id), {})
            alerts.append({
                "cluster_id": int(cluster_id),
                "issue": cluster.get("label", f"Cluster {cluster_id}"),
                "product": "Dataset-local semantic issue",
                "current_count": int(current_count),
                "expected_count": round(float(expected), 1),
                "absolute_change": round(float(current_count - expected), 1),
                "lift": round(float(lift), 2),
                "z_score": round(float(z_score), 2),
                "alert": True,
                "alert_reason": "Current activity is materially above baseline",
                "current_window_days": current_days,
                "baseline_window_days": baseline_days,
            })

    alerts.sort(key=lambda x: ((x.get("z_score") or 999), (x.get("lift") or 999), x["current_count"]), reverse=True)
    summary = {
        "date_available": True,
        "start_date": str(min_date.date()),
        "end_date": str(max_date.date()),
        "span_days": span_days,
        "current_days": current_days,
        "baseline_days": baseline_days,
        "alert_note": "Formal alerts compare the latest 7 days with the preceding baseline and require a meaningful lift and count threshold.",
    }
    return alerts, summary


def _sentiment_percent(counts: dict[str, int]) -> dict[str, float]:
    total = max(1, sum(counts.values()))
    return {k: round(v / total * 100, 1) for k, v in counts.items()}


def _safe_value(value: Any) -> str:
    if pd.isna(value):
        return ""
    if isinstance(value, pd.Timestamp):
        return value.isoformat()
    return str(value)


def build_generic_analysis(df: pd.DataFrame, text_column: str, date_column: str | None, label_column: str | None, progress_cb=None) -> dict[str, Any]:
    def progress(value: int, stage: str, detail: str = "") -> None:
        if progress_cb:
            progress_cb(int(max(0, min(100, value))), stage, detail)

    working = df.copy()
    source_rows = len(working)
    progress(5, "Preparing dataset", "Cleaning the automatically detected semantic field")
    working[text_column] = (
        working[text_column]
        .fillna("")
        .astype(str)
        .str.replace(r"\s+", " ", regex=True)
        .str.strip()
    )
    working = working[working[text_column].str.len() >= 3].copy()
    usable_rows = len(working)
    if working.empty:
        raise ValueError("No usable text rows were found after cleaning.")

    ml_sampled = len(working) > MAX_ML_ROWS
    if ml_sampled:
        # Deterministic sample so repeated uploads are reproducible.
        ml_working = working.sample(MAX_ML_ROWS, random_state=42).copy()
    else:
        ml_working = working.copy()

    texts = ml_working[text_column].tolist()
    progress(12, "Loading semantic model", "Preparing MiniLM embeddings")
    model = embedding_model()
    embedding_parts: list[np.ndarray] = []
    embed_batch = 256
    total = len(texts)
    for start in range(0, total, embed_batch):
        batch = model.encode(
            texts[start:start + embed_batch],
            batch_size=64,
            show_progress_bar=False,
            normalize_embeddings=True,
            convert_to_numpy=True,
        ).astype(np.float32)
        embedding_parts.append(batch)
        progress(15 + int((start + len(batch)) / total * 35), "Building semantic embeddings", f"{min(start + len(batch), total):,} / {total:,} rows")
    embeddings = np.vstack(embedding_parts).astype(np.float32)

    k = choose_cluster_count(len(texts))
    progress(53, "Discovering incident themes", f"Choosing {k} semantic groups automatically")
    if k == 1:
        assignments = np.zeros(len(texts), dtype=int)
        centers = embeddings.mean(axis=0, keepdims=True)
        centers = normalize(centers)
    else:
        km = MiniBatchKMeans(
            n_clusters=k,
            random_state=42,
            batch_size=min(1024, max(64, len(texts))),
            n_init=5,
            max_iter=250,
        )
        assignments = km.fit_predict(embeddings)
        centers = normalize(km.cluster_centers_.astype(np.float32))

    progress(64, "Interpreting clusters", f"Generating labels and representative evidence for {k} groups")
    cluster_list: list[dict[str, Any]] = []
    cluster_centroids: dict[str, list[float]] = {}
    records: list[dict[str, Any]] = []

    for cluster_id in sorted(set(int(x) for x in assignments)):
        indices = np.where(assignments == cluster_id)[0].tolist()
        cluster_texts = [texts[i] for i in indices]
        label, keywords = make_cluster_label(cluster_texts)
        centroid = centers[cluster_id]
        cluster_centroids[str(cluster_id)] = centroid.astype(np.float32).tolist()
        sims = embeddings[indices] @ centroid
        order = np.argsort(sims)[::-1]
        example_indices = [indices[int(i)] for i in order[:8]]

        purity = None
        top_label = None
        if label_column and label_column in ml_working.columns:
            labels = ml_working.iloc[indices][label_column].fillna("Unknown").astype(str).tolist()
            counts = pd.Series(labels).value_counts()
            if len(counts):
                top_label = str(counts.index[0])
                purity = float(counts.iloc[0] / len(labels))

        cluster_list.append({
            "cluster_id": cluster_id,
            "label": label,
            "size": len(indices),
            "coverage": len(indices) / len(texts),
            "purity": purity,
            "reference_label": top_label,
            "keywords": keywords[:8],
            "examples": [texts[i] for i in example_indices],
        })

        for i in indices:
            row = {
                "text": texts[i],
                "cluster_id": cluster_id,
                "cluster_label": label,
            }
            if date_column and date_column in ml_working.columns:
                row["date"] = _safe_value(ml_working.iloc[i][date_column])
            if label_column and label_column in ml_working.columns:
                row["label"] = _safe_value(ml_working.iloc[i][label_column])
            records.append(row)

    progress(72, "Running sentiment inference", "Scoring the analyzed text with Hartmann RoBERTa")
    sentiment_counts = {"positive": 0, "neutral": 0, "negative": 0}
    sentiment = sentiment_model()
    for start in range(0, len(texts), 64):
        preds = sentiment(texts[start:start + 64], truncation=True, max_length=128)
        for pred in preds:
            label = sentiment_label(pred["label"])
            sentiment_counts[label] = sentiment_counts.get(label, 0) + 1
        progress(72 + int((min(start + 64, len(texts)) / len(texts)) * 18), "Running sentiment inference", f"{min(start + 64, len(texts)):,} / {len(texts):,} rows")

    trend_rows: list[dict[str, Any]] = []
    alerts: list[dict[str, Any]] = []
    alert_summary: dict[str, Any] = {"date_available": False}
    parsed_dates = None
    if date_column and date_column in working.columns:
        parsed_dates = pd.to_datetime(working[date_column], errors="coerce")
        # Only use the analyzed rows for trend/alert calculations so cluster IDs and observations align.
        parsed_dates_ml = parsed_dates.loc[ml_working.index]
        valid = parsed_dates_ml.notna()
        if valid.any():
            valid_dates = parsed_dates_ml.loc[valid].dt.normalize().reset_index(drop=True)
            valid_clusters = assignments[valid.to_numpy()]
            temp = pd.DataFrame({"date": valid_dates, "cluster_id": valid_clusters})
            grouped = temp.groupby(["date", "cluster_id"]).size().reset_index(name="count")
            trend_rows = [
                {"date": str(row["date"].date()), "cluster_id": int(row["cluster_id"]), "count": int(row["count"])}
                for _, row in grouped.iterrows()
            ]
            cluster_map = {int(c["cluster_id"]): c for c in cluster_list}
            alerts, alert_summary = build_alerts(parsed_dates_ml, assignments, cluster_map)
        else:
            alert_summary = {"date_available": True, "alert_note": "A candidate date field was detected, but its values could not be parsed."}

    progress(96, "Building dashboard signals", "Finalizing sentiment, trend, alert, and cluster summaries")
    notes: list[str] = [
        f"{source_rows:,} source rows found; {usable_rows:,} contain usable text.",
        f"{len(texts):,} rows used for semantic discovery and sentiment inference.",
        f"Automatic semantic grouping produced {len(cluster_list)} issue clusters.",
    ]
    if ml_sampled:
        notes.append(f"Large-dataset safety mode: a deterministic {MAX_ML_ROWS:,}-row sample was used for ML discovery and sentiment.")
    if date_column is None:
        notes.append("No reliable date field was detected; trend monitoring and formal surge alerts are disabled.")
    elif not trend_rows:
        notes.append("A date field was detected, but no usable dated activity was produced for trend monitoring.")
    else:
        notes.append(f"Date field detected automatically: {date_column}. Trend monitoring is enabled on the analyzed sample.")
    if label_column is None:
        notes.append("No reliable evaluation field was detected; cluster purity is shown as unavailable rather than inferred.")
    else:
        notes.append(f"Evaluation field detected automatically: {label_column}.")
    if alert_summary.get("alert_note"):
        notes.append(str(alert_summary["alert_note"]))

    progress(100, "Analysis complete", f"{len(texts):,} rows analyzed successfully")
    return {
        "rows": source_rows,
        "source_rows": source_rows,
        "usable_rows": usable_rows,
        "rows_analyzed": len(texts),
        "truncated": ml_sampled,
        "clusters": sorted(cluster_list, key=lambda x: x["size"], reverse=True),
        "cluster_centroids": cluster_centroids,
        "records": records,
        "trend_rows": trend_rows,
        "alerts": alerts,
        "alert_summary": alert_summary,
        "sentiment": sentiment_counts,
        "sentiment_percent": _sentiment_percent(sentiment_counts),
        "notes": notes,
    }


def builtin_clusters() -> list[dict[str, Any]]:
    report = load_json(REPORTS / "discovered_issue_topics_v2.json")
    result = []
    for cluster in report.get("clusters", []):
        c = dict(cluster)
        examples = c.get("examples") or c.get("sample_texts") or c.get("representative_texts") or []
        if isinstance(examples, str):
            examples = [examples]
        c["examples"] = examples[:8]
        result.append(c)
    return result


def current_clusters() -> list[dict[str, Any]]:
    return builtin_clusters() if CURRENT_DATASET["kind"] == "builtin" else CURRENT_DATASET.get("clusters", [])


def current_overview() -> dict[str, Any]:
    dataset_fields = ("id", "name", "kind", "rows", "source_rows", "rows_analyzed", "usable_rows", "truncated", "text_column", "date_column", "label_column", "detected_columns")
    if CURRENT_DATASET["kind"] == "builtin":
        trend_rows = read_csv_rows(REPORTS / "cfpb_product_issue_trend_scores_matured.csv")
        alert_count = sum(1 for row in trend_rows if str(row.get("alert", "")).lower() == "true")
        topics = load_json(REPORTS / "discovered_issue_topics_v2.json")
        return {
            "dataset": {k: CURRENT_DATASET.get(k) for k in dataset_fields},
            "cuda": bool(torch.cuda.is_available()),
            "gpu": torch.cuda.get_device_name(0) if torch.cuda.is_available() else None,
            "trend_summary": load_json(REPORTS / "cfpb_product_issue_trend_summary_matured.json"),
            "trend_groups_available": len(trend_rows),
            "formal_alerts": alert_count,
            "discovered_issue_cluster_count": topics.get("cluster_count", len(builtin_clusters())),
            "sentiment": CURRENT_DATASET.get("sentiment", {}),
            "sentiment_percent": CURRENT_DATASET.get("sentiment_percent", {}),
            "embedding_model": "sentence-transformers/all-MiniLM-L6-v2",
            "sentiment_model": "j-hartmann/sentiment-roberta-large-english-3-classes",
            "semantic_target": "BANKING77 intent",
            "notes": CURRENT_DATASET.get("notes", []),
        }

    trend_rows = CURRENT_DATASET.get("trend_rows", [])
    trend_groups = len({int(r["cluster_id"]) for r in trend_rows}) if trend_rows else 0
    return {
        "dataset": {k: CURRENT_DATASET.get(k) for k in dataset_fields},
        "cuda": bool(torch.cuda.is_available()),
        "gpu": torch.cuda.get_device_name(0) if torch.cuda.is_available() else None,
        "trend_summary": CURRENT_DATASET.get("alert_summary", {"date_available": False}),
        "trend_groups_available": trend_groups,
        "formal_alerts": len(CURRENT_DATASET.get("alerts", [])),
        "discovered_issue_cluster_count": len(CURRENT_DATASET.get("clusters", [])),
        "sentiment": CURRENT_DATASET.get("sentiment", {}),
        "sentiment_percent": CURRENT_DATASET.get("sentiment_percent", {}),
        "embedding_model": "sentence-transformers/all-MiniLM-L6-v2",
        "sentiment_model": "j-hartmann/sentiment-roberta-large-english-3-classes",
        "semantic_target": "Discovered semantic issue cluster",
        "notes": CURRENT_DATASET.get("notes", []),
    }


@app.get("/", include_in_schema=False)
def web_ui():
    if not INDEX_HTML.exists():
        raise HTTPException(status_code=500, detail="Web UI assets are missing.")
    return FileResponse(INDEX_HTML, headers={"Cache-Control": "no-store"})


@app.get("/health")
def health():
    return {
        "status": "ok",
        "cuda": bool(torch.cuda.is_available()),
        "gpu": torch.cuda.get_device_name(0) if torch.cuda.is_available() else None,
        "ui": INDEX_HTML.exists(),
        "dataset": CURRENT_DATASET.get("name"),
        "dataset_kind": CURRENT_DATASET.get("kind"),
        "version": app.version,
    }


@app.get("/api/v1/overview")
def overview():
    return current_overview()


@app.get("/api/v1/dataset")
def dataset():
    overview_data = current_overview()
    return {
        "dataset": overview_data["dataset"],
        "sentiment": overview_data["sentiment"],
        "sentiment_percent": overview_data["sentiment_percent"],
        "notes": overview_data["notes"],
    }


@app.get("/api/v1/alerts")
def alerts():
    if CURRENT_DATASET["kind"] == "builtin":
        path = REPORTS / "cfpb_product_issue_trend_scores_matured.csv"
        if not path.exists():
            return {"count": 0, "alerts": [], "summary": {"date_available": True}}
        rows = read_csv_rows(path)
        alert_rows = [row for row in rows if str(row.get("alert", "")).lower() == "true"]
        return {"count": len(alert_rows), "alerts": alert_rows, "summary": {"date_available": True}}
    return {
        "count": len(CURRENT_DATASET.get("alerts", [])),
        "alerts": CURRENT_DATASET.get("alerts", []),
        "summary": CURRENT_DATASET.get("alert_summary", {}),
    }


@app.get("/api/v1/trends")
def trends(limit: int = 50):
    if limit < 1 or limit > 200:
        raise HTTPException(status_code=400, detail="limit must be 1-200")
    if CURRENT_DATASET["kind"] == "builtin":
        path = REPORTS / "cfpb_product_issue_trend_scores_matured.csv"
        if not path.exists():
            return {"count": 0, "trends": []}
        rows = read_csv_rows(path)
        return {"count": min(limit, len(rows)), "trends": rows[:limit]}
    rows = list(CURRENT_DATASET.get("trend_rows", []))
    rows.sort(key=lambda x: (x.get("date", ""), int(x.get("cluster_id", 0))), reverse=True)
    return {"count": min(limit, len(rows)), "trends": rows[:limit]}


@app.post("/api/v1/analyze", response_model=AnalyzeResponse)
def analyze(request: AnalyzeRequest):
    text = request.text.strip()
    model = embedding_model()
    sentiment = sentiment_model()
    vector = model.encode([text], normalize_embeddings=True, convert_to_numpy=True).astype(np.float32)
    sentiment_pred = sentiment(text, truncation=True, max_length=128)[0]

    if CURRENT_DATASET["kind"] == "builtin":
        centroids, labels = intent_index()
        similarity = vector @ centroids.T
        best_idx = int(np.argmax(similarity))
        target = labels[best_idx]
        target_type = "BANKING77 intent"
        score = float(similarity[0, best_idx])
    else:
        centroids_map: dict[str, list[float]] = CURRENT_DATASET.get("cluster_centroids", {})
        clusters = {str(c.get("cluster_id")): c for c in CURRENT_DATASET.get("clusters", [])}
        if not centroids_map:
            raise HTTPException(status_code=409, detail="The active dataset has no semantic index. Analyze the dataset again.")
        ordered_ids = [cid for cid in sorted(centroids_map, key=lambda x: int(x)) if cid in clusters]
        matrix = np.asarray([centroids_map[cid] for cid in ordered_ids], dtype=np.float32)
        matrix = normalize(matrix)
        similarity = vector @ matrix.T
        best_idx = int(np.argmax(similarity))
        cluster_id = ordered_ids[best_idx]
        target = str(clusters[cluster_id].get("label", f"Cluster {cluster_id}"))
        target_type = "discovered issue cluster"
        score = float(similarity[0, best_idx])

    label = sentiment_label(sentiment_pred["label"])
    return AnalyzeResponse(
        text=text,
        sentiment=label,
        sentiment_confidence=round(float(sentiment_pred["score"]), 6),
        semantic_target=target,
        semantic_target_type=target_type,
        semantic_similarity=round(score, 6),
        nearest_intent=target,
        nearest_intent_similarity=round(score, 6),
        dataset=CURRENT_DATASET["name"],
    )


@app.get("/api/v1/discovered-issues")
def discovered_issues(limit: int = 100):
    if limit < 1 or limit > 200:
        raise HTTPException(status_code=400, detail="limit must be 1-200")
    clusters = current_clusters()[:limit]
    return {"count": len(clusters), "clusters": clusters, "dataset": CURRENT_DATASET.get("name"), "interactive": True}


@app.get("/api/v1/discovered-issues/{cluster_id}")
def discovered_issue_detail(cluster_id: int):
    clusters = current_clusters()
    cluster = next((c for c in clusters if int(c.get("cluster_id", c.get("id", -999))) == cluster_id), None)
    if cluster is None:
        raise HTTPException(status_code=404, detail="Cluster not found.")
    detail = dict(cluster)
    examples = detail.get("examples") or detail.get("sample_texts") or detail.get("representative_texts") or []
    if isinstance(examples, str):
        examples = [examples]
    detail["examples"] = list(examples)[:10]
    if not detail["examples"] and CURRENT_DATASET["kind"] != "builtin":
        detail["examples"] = [r.get("text", "") for r in CURRENT_DATASET.get("records", []) if int(r.get("cluster_id", -1)) == cluster_id][:10]
    return {"dataset": CURRENT_DATASET.get("name"), "cluster": detail}


def set_job_progress(job_id: str, value: int, stage: str, detail: str = "") -> None:
    job = ANALYSIS_JOBS.get(job_id)
    if job is not None:
        job.update({"progress": int(value), "stage": stage, "detail": detail})


def run_dataset_analysis(job_id: str, upload_id: str) -> None:
    payload = PENDING_UPLOADS.get(upload_id)
    if not payload:
        ANALYSIS_JOBS[job_id].update({"status": "failed", "progress": 100, "stage": "Analysis failed", "detail": "Upload session was not found."})
        return
    path: Path = payload["path"]
    try:
        ANALYSIS_JOBS[job_id]["status"] = "running"
        set_job_progress(job_id, 2, "Reading dataset", payload["name"])
        df = read_uploaded_dataframe(path)
        detected = payload["detected"]
        text_column = detected.get("text_column")
        if not text_column or text_column not in df.columns:
            raise ValueError("No usable text column could be detected automatically.")
        result = build_generic_analysis(
            df,
            text_column,
            detected.get("date_column"),
            detected.get("label_column"),
            progress_cb=lambda value, stage, detail="": set_job_progress(job_id, value, stage, detail),
        )
        with DATASET_LOCK:
            CURRENT_DATASET.clear()
            CURRENT_DATASET.update({
                "id": upload_id,
                "name": payload["name"],
                "kind": "upload",
                "text_column": text_column,
                "date_column": detected.get("date_column"),
                "label_column": detected.get("label_column"),
                "detected_columns": detected.get("columns", []),
                **result,
            })
            save_active_dataset()
        ANALYSIS_JOBS[job_id].update({
            "status": "complete",
            "progress": 100,
            "stage": "Analysis complete",
            "detail": f"{result['rows_analyzed']:,} rows analyzed",
            "dataset": current_overview(),
            "detected": detected,
        })
    except Exception as exc:
        ANALYSIS_JOBS[job_id].update({"status": "failed", "progress": 100, "stage": "Analysis failed", "detail": str(exc)})
    finally:
        PENDING_UPLOADS.pop(upload_id, None)
        path.unlink(missing_ok=True)


@app.post("/api/v1/datasets/upload")
async def upload_dataset(file: UploadFile = File(...)):
    suffix = Path(file.filename or "").suffix.lower()
    if suffix not in {".csv", ".xlsx", ".xlsm", ".xls"}:
        raise HTTPException(status_code=400, detail="Upload a CSV, XLSX, XLSM, or XLS file.")
    content = await file.read(MAX_UPLOAD_BYTES + 1)
    if len(content) > MAX_UPLOAD_BYTES:
        raise HTTPException(status_code=413, detail="File is too large. Maximum upload size is 25 MB.")
    upload_id = uuid.uuid4().hex
    job_id = uuid.uuid4().hex
    path = UPLOADS / f"{upload_id}{suffix}"
    path.write_bytes(content)
    try:
        df = read_uploaded_dataframe(path)
    except Exception as exc:
        path.unlink(missing_ok=True)
        raise HTTPException(status_code=400, detail=f"Could not read dataset: {exc}") from exc

    detected = detect_columns(df)
    preview = df.head(PREVIEW_ROWS).fillna("").astype(str).to_dict(orient="records")
    PENDING_UPLOADS[upload_id] = {"path": path, "name": file.filename or path.name, "detected": detected}
    ANALYSIS_JOBS[job_id] = {
        "job_id": job_id,
        "upload_id": upload_id,
        "filename": file.filename or path.name,
        "status": "queued",
        "progress": 0,
        "stage": "Queued",
        "detail": "Automatic schema detection complete. Analysis is starting.",
        "detected": detected,
    }
    ANALYSIS_EXECUTOR.submit(run_dataset_analysis, job_id, upload_id)
    return {
        "upload_id": upload_id,
        "job_id": job_id,
        "filename": file.filename or path.name,
        "detected": detected,
        "preview": preview,
        "status": "queued",
        "auto_analysis": True,
    }


@app.get("/api/v1/datasets/jobs/{job_id}")
def dataset_job_status(job_id: str):
    job = ANALYSIS_JOBS.get(job_id)
    if not job:
        raise HTTPException(status_code=404, detail="Analysis job not found.")
    response = dict(job)
    if response.get("status") == "complete":
        response["dataset"] = current_overview()
    return response


@app.post("/api/v1/datasets/reset")
def reset_dataset():
    CURRENT_DATASET.clear()
    CURRENT_DATASET.update(copy.deepcopy(BENCHMARK_DATASET))
    ACTIVE_DATASET_PATH.unlink(missing_ok=True)
    return current_overview()
