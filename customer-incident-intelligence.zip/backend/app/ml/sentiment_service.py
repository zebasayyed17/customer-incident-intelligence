"""Sentiment inference service using a pretrained RoBERTa classifier."""

from __future__ import annotations

from typing import Sequence

from transformers import pipeline

from .models import SENTIMENT_MODEL


class SentimentService:
    def __init__(self, model_name: str = SENTIMENT_MODEL, device: int = -1) -> None:
        # device=-1 => CPU. A CUDA device index such as 0 can be supplied later.
        self.pipeline = pipeline(
            "text-classification",
            model=model_name,
            tokenizer=model_name,
            device=device,
        )

    def predict(self, texts: Sequence[str]) -> list[dict[str, float | str]]:
        if not texts:
            return []
        results = self.pipeline(list(texts), truncation=True)
        return [
            {"label": str(item["label"]), "score": float(item["score"])}
            for item in results
        ]
