const API = "";

const state = { overview:null, alerts:[], trends:[], clusters:[], preview:null, jobId:null };
const $ = (id) => document.getElementById(id);

function esc(value){return String(value ?? "").replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;").replace(/'/g,"&#039;");}
function num(value,digits=0){const n=Number(value);return Number.isFinite(n)?n.toLocaleString(undefined,{maximumFractionDigits:digits}):"—";}
function first(obj,keys,fallback="—"){for(const k of keys){if(obj&&obj[k]!==undefined&&obj[k]!==null&&obj[k]!=="")return obj[k]}return fallback}

async function api(path,options={}){
  const init={...options,headers:{...(options.headers||{})}};
  if(!(options.body instanceof FormData))init.headers["Content-Type"]="application/json";
  const r=await fetch(`${API}${path}`,init);
  if(!r.ok){let msg=`Request failed (${r.status})`;try{const b=await r.json();msg=b.detail||msg}catch{}throw new Error(msg)}
  return r.json();
}
function toast(message){const t=$("toast");if(!t)return;t.textContent=message;t.classList.add("show");clearTimeout(toast.timer);toast.timer=setTimeout(()=>t.classList.remove("show"),2800)}
function setView(target){document.querySelectorAll(".view").forEach(v=>v.classList.toggle("active-view",v.id===target));document.querySelectorAll(".nav-item").forEach(v=>v.classList.toggle("active",v.dataset.target===target));const titles={dashboard:"Operations Overview",alerts:"Incident Alerts",trends:"Trend Monitor",discovery:"Incident Discovery",datasets:"Dataset Lab",analyzer:"NLP Analyzer"};$("page-title").textContent=titles[target]||"Operations Overview";window.scrollTo({top:0,behavior:"smooth"})}
function dataset(){return state.overview?.dataset||{}}
function clusterTitle(c){return first(c,["label","topic_label","name","title"],`Cluster ${first(c,["cluster_id","id"],"—")}`)}

function renderOverview(){
  const d=dataset(), alertCount=Number(state.overview?.formal_alerts??state.alerts.length), sentiment=state.overview?.sentiment_percent||{};
  $("hero-alert-count").textContent=num(alertCount);
  $("hero-source").textContent=`${d.name||"Dataset"} · ${d.kind==="upload"?"custom dataset":"benchmark dataset"}`;
  $("kpi-source-rows").textContent=num(d.source_rows??d.rows);
  $("kpi-source-note").textContent=d.truncated?"ML safety sample used":"rows loaded";
  $("kpi-analyzed-rows").textContent=num(d.rows_analyzed??d.rows);
  $("kpi-analyzed-note").textContent=d.usable_rows!=null?`${num(d.usable_rows)} usable text rows`:"semantic + sentiment";
  $("kpi-clusters").textContent=num(state.overview?.discovered_issue_cluster_count);
  const ts=state.overview?.trend_summary||{};
  $("kpi-date").textContent=ts.date_available&&ts.start_date?`${num(ts.span_days)}d`:"None";
  $("kpi-date-note").textContent=ts.date_available&&ts.start_date?`${ts.start_date} → ${ts.end_date}`:"no reliable date field";
  $("dataset-pill").textContent=d.name||"Dataset";$("dataset-sidebar").textContent=`${d.name||"Dataset"} · ${d.kind==="upload"?"custom":"benchmark"}`;$("dataset-heading").textContent=d.name||"Dataset";
  $("analyzer-target-note").textContent=d.kind==="upload"?"Semantic target: discovered issue cluster":"Semantic target: BANKING77 intent";
  renderSentiment(sentiment);renderAlertCards($("dashboard-alerts"),state.alerts.slice(0,4));renderNotes();renderSchemaSummary();
}
function renderSentiment(pct){
  const items=["positive","neutral","negative"], total=(state.overview?.sentiment||{});$("sentiment-grid").innerHTML=items.map(k=>`<div class="sentiment-card"><div class="sentiment-head"><span class="sentiment-name">${k}</span><span class="sentiment-pct">${num(pct[k]??0,1)}%</span></div><div class="sentiment-track"><div class="sentiment-fill fill-${k}" style="width:${Math.max(0,Math.min(100,Number(pct[k]||0)))}%"></div></div><div class="muted" style="margin-top:8px">${num(total[k]??0)} analyzed rows</div></div>`).join("");
  $("sentiment-subtitle").textContent=`${num(Object.values(total).reduce((a,b)=>a+Number(b||0),0))} text rows scored`;
}
function renderAlertCards(host,alerts){
  if(!alerts.length){const d=dataset(), hasDate=Boolean(d.date_column);host.innerHTML=`<div class="empty-state"><div><div class="empty-icon">OK</div><h3>No formal alerts</h3><p>${hasDate?"No cluster crossed the configured surge thresholds.":"No reliable date field was detected, so formal surge alerts are not available."}</p></div></div>`;return}
  host.innerHTML=alerts.map(a=>{const current=first(a,["current_count","current"]), expected=first(a,["expected_count","expected"]), lift=a.lift==null?"—":`${num(a.lift,2)}×`, z=a.z_score==null?"—":num(a.z_score,2);return `<article class="alert-card"><div class="alert-top"><div class="alert-tag">FORMAL ALERT</div><div class="muted">${esc(first(a,["product"],"Dataset-local"))} · Cluster ${esc(a.cluster_id)}</div></div><div class="alert-title">${esc(first(a,["issue"],"Unknown issue"))}</div><div class="alert-metrics"><div class="metric-box"><div class="label">Current</div><div class="value">${num(current)}</div></div><div class="metric-box"><div class="label">Expected</div><div class="value">${num(expected,1)}</div></div><div class="metric-box"><div class="label">Lift</div><div class="value">${lift}</div></div></div><div class="muted" style="margin-top:10px">${esc(first(a,["alert_reason"],"Current activity exceeded baseline"))} · z-score ${esc(z)}</div></article>`}).join("")
}
function renderAlerts(){$("alert-count-badge").textContent=num(state.alerts.length);renderAlertCards($("alerts-list"),state.alerts)}
function renderTrends(){
  const rows=[...state.trends], d=dataset(), dateAvailable=Boolean(d.date_column||state.overview?.trend_summary?.date_available);
  if(!rows.length){$("trend-bars").innerHTML=`<div class="empty-state"><div><h3>${dateAvailable?"No dated activity to display":"Trend monitoring is not applicable"}</h3><p>${dateAvailable?"The detected date field did not produce usable trend observations.":"The active dataset has no reliable date field. Upload a dataset containing dates to enable this section."}</p></div></div>`;$("trend-table").innerHTML="";$("trend-subtitle").textContent=dateAvailable?"No usable dated activity":"No date field detected";return}
  const top=rows.slice(0,25);const max=Math.max(1,...top.map(r=>Number(r.count||r.current_count||0)));
  $("trend-bars").innerHTML=top.map(r=>{const count=Number(r.count||r.current_count||0),w=Math.max(4,Math.round(count/max*100)),c=state.clusters.find(x=>Number(x.cluster_id)===Number(r.cluster_id)),label=c?clusterTitle(c):`Cluster ${r.cluster_id}`;return `<div class="bar-row"><div><div class="bar-product">${esc(r.date||r.product||"")}</div><div class="bar-issue">${esc(label)}</div></div><div class="bar-track"><div class="bar-fill" style="width:${w}%"></div></div><div class="bar-number">${num(count)}</div></div>`}).join("");
  $("trend-table").innerHTML=top.map(r=>{const c=state.clusters.find(x=>Number(x.cluster_id)===Number(r.cluster_id)),label=c?clusterTitle(c):`Cluster ${r.cluster_id}`,count=Number(r.count||r.current_count||0);return `<tr><td>${esc(r.date||"—")}</td><td>${esc(label)}</td><td>${num(count)}</td><td>${esc(r.current_count??"—")}</td><td>${esc(r.expected_count??"—")}</td><td>${r.lift==null?"—":num(r.lift,2)+"×"}</td><td class="status-normal">MONITORED</td></tr>`}).join("");
  const s=state.overview?.trend_summary||{};$("trend-subtitle").textContent=s.start_date?`${d.date_column||"date"} · ${s.start_date} → ${s.end_date}`:"Current dated activity";
}
function renderDiscovery(){
  const cs=state.clusters;if(!cs.length){$("discovery-grid").innerHTML=`<div class="empty-state"><div><h3>No discovered themes</h3><p>Upload a text dataset or complete benchmark discovery.</p></div></div>`;return}
  $("discovery-grid").innerHTML=cs.map(c=>{const id=first(c,["cluster_id","id"]),size=first(c,["size","count"]),purity=c.purity==null?"—":num(c.purity,2),coverage=c.coverage==null?"—":`${num(Number(c.coverage)*100,1)}%`,keys=Array.isArray(c.keywords)?c.keywords:[];return `<button class="discovery-card" data-cluster-id="${esc(id)}" type="button"><div class="cluster-head"><div class="cluster-id">CLUSTER ${esc(id)}</div><span class="inspect-chip">Inspect →</span></div><div class="cluster-title">${esc(clusterTitle(c))}</div><div class="cluster-meta"><span>Size ${num(size)}</span><span>Purity ${esc(purity)}</span><span>Coverage ${esc(coverage)}</span></div><div class="keyword-list">${keys.slice(0,7).map(k=>`<span class="keyword">${esc(k)}</span>`).join("")}</div></button>`}).join("");
  document.querySelectorAll(".discovery-card").forEach(el=>el.addEventListener("click",()=>openCluster(el.dataset.clusterId)));
}
function renderNotes(){const notes=state.overview?.notes||[];$("dataset-notes").innerHTML=notes.map(n=>`<div class="notice"><span class="notice-dot"></span>${esc(n)}</div>`).join("")||`<div class="notice"><span class="notice-dot"></span>Dataset is ready.</div>`}
function renderSchemaSummary(){const d=dataset();$("dataset-schema-summary").innerHTML=`<div class="schema-tile"><span>Text field</span><strong>${esc(d.text_column||"Not detected")}</strong></div><div class="schema-tile"><span>Date field</span><strong>${esc(d.date_column||"Not detected")}</strong></div><div class="schema-tile"><span>Evaluation field</span><strong>${esc(d.label_column||"Not detected")}</strong></div>`}
function renderPreview(preview){if(!preview?.length){$("preview-table").innerHTML=`<div class="empty-state"><h3>No preview available</h3></div>`;return}const cols=Object.keys(preview[0]);$("preview-table").innerHTML=`<table class="preview-table"><thead><tr>${cols.map(c=>`<th>${esc(c)}</th>`).join("")}</tr></thead><tbody>${preview.slice(0,8).map(r=>`<tr>${cols.map(c=>`<td title="${esc(r[c])}">${esc(r[c])}</td>`).join("")}</tr>`).join("")}</tbody></table>`}
function renderDetected(d){$("schema-detected").innerHTML=[
  ["Text",d.text_column||"Not detected"],
  ["Date",d.date_column||"Not detected"],
  ["Evaluation",d.label_column||"Not detected"],
  ["Rows",num(d.row_count)],
].map(([k,v])=>`<div class="detected-field"><span>${esc(k)}</span><strong>${esc(v)}</strong></div>`).join("")}
function setProgress(v,stage,detail){$("analysis-stage").textContent=stage||"Working…";$("analysis-percent").textContent=`${Number(v||0)}%`;$("analysis-bar").style.width=`${Math.max(0,Math.min(100,Number(v||0)))}%`;$("analysis-detail").textContent=detail||""}

async function pollJob(jobId){
  state.jobId=jobId;let finished=false;
  while(!finished){const job=await api(`/api/v1/datasets/jobs/${encodeURIComponent(jobId)}`);setProgress(job.progress||0,job.stage,job.detail);if(job.status==="complete"){finished=true;state.overview=job.dataset;await reloadDataViews();toast("Dataset analysis complete.");setView("dashboard")}else if(job.status==="failed"){throw new Error(job.detail||"Dataset analysis failed.")}else{await new Promise(r=>setTimeout(r,650))}}
}
async function handleFile(file){
  if(!file)return;
  $("upload-file-meta").classList.remove("hidden");$("upload-file-meta").innerHTML=`<strong>${esc(file.name)}</strong><span>${num(file.size/1024/1024,2)} MB · uploading…</span>`;$("schema-box").classList.remove("hidden");setProgress(0,"Uploading dataset","Sending file to the analysis engine…");
  try{const form=new FormData();form.append("file",file);const result=await api("/api/v1/datasets/upload",{method:"POST",body:form});state.preview=result;renderPreview(result.preview);renderDetected(result.detected);$("upload-file-meta").innerHTML=`<strong>${esc(result.filename)}</strong><span>${num(result.detected.row_count)} rows · ${result.detected.columns.length} columns</span>`;$("preview-meta").textContent=`${num(result.detected.row_count)} rows · ${result.detected.columns.length} columns`;setProgress(1,"Queued","Automatic analysis has started.");await pollJob(result.job_id)}catch(e){setProgress(100,"Analysis failed",e.message);$("upload-file-meta").innerHTML=`<span class="error-text">${esc(e.message)}</span>`;toast(e.message)}
}
async function resetDataset(){const b=$("reset-dataset-btn");b.disabled=true;try{const r=await api("/api/v1/datasets/reset",{method:"POST"});state.overview=r;state.preview=null;$("schema-box").classList.add("hidden");$("upload-file-meta").classList.add("hidden");$("preview-meta").textContent="No file selected";$("preview-table").innerHTML=`<div class="empty-state"><h3>No dataset loaded</h3><p>Drop a CSV or Excel file. The platform will inspect it and run automatically.</p></div>`;await reloadDataViews();toast("Reset to BANKING77.")}catch(e){toast(e.message)}finally{b.disabled=false}}
async function reloadDataViews(){const [o,a,t,c,h]=await Promise.all([api("/api/v1/overview"),api("/api/v1/alerts"),api("/api/v1/trends?limit=100"),api("/api/v1/discovered-issues?limit=100"),api("/health")]);state.overview=o;state.alerts=a.alerts||[];state.trends=t.trends||[];state.clusters=c.clusters||[];$("api-dot").className="status-dot online";$("api-status").textContent="API online";$("gpu-pill").textContent=h.cuda?`GPU · ${h.gpu||"CUDA"}`:"CPU inference";renderOverview();renderAlerts();renderTrends();renderDiscovery()}
async function loadAll(){try{await reloadDataViews()}catch(e){$("api-dot").className="status-dot offline";$("api-status").textContent="API unavailable";["dashboard-alerts","alerts-list","trend-bars","discovery-grid"].forEach(id=>{const n=$(id);if(n)n.innerHTML=`<div class="error-box">${esc(e.message)}</div>`})}}
async function analyzeComplaint(){const text=$("complaint-input").value.trim();if(text.length<3){toast("Enter at least 3 characters.");return}const b=$("analyze-btn");b.disabled=true;b.textContent="Analyzing…";try{const d=await api("/api/v1/analyze",{method:"POST",body:JSON.stringify({text})});const conf=Number(d.sentiment_confidence||0),sim=Number(d.semantic_similarity||0);$("analysis-result").innerHTML=`<div class="eyebrow">INFERENCE RESULT · ${esc(d.dataset)}</div><h3>${esc(d.text)}</h3><div class="result-grid"><div class="result-box"><div class="r-label">Sentiment</div><span class="sentiment-pill sentiment-${esc(d.sentiment)}">${esc(d.sentiment)}</span></div><div class="result-box"><div class="r-label">Confidence</div><div class="r-value">${num(conf*100,1)}%</div><div class="progress"><div style="width:${Math.min(100,conf*100)}%"></div></div></div><div class="result-box wide"><div class="r-label">Semantic target · ${esc(d.semantic_target_type)}</div><div class="r-value">${esc(d.semantic_target)}</div></div><div class="result-box wide"><div class="r-label">Semantic similarity</div><div class="r-value">${num(sim,3)}</div><div class="progress"><div style="width:${Math.min(100,sim*100)}%"></div></div></div></div>`}catch(e){$("analysis-result").innerHTML=`<div class="error-box">${esc(e.message)}</div>`}finally{b.disabled=false;b.textContent="Analyze text"}}
async function openCluster(id){const modal=$("cluster-modal"),detail=$("cluster-detail");modal.classList.remove("hidden");modal.setAttribute("aria-hidden","false");detail.innerHTML=`<div class="loading">Loading cluster evidence…</div>`;try{const d=await api(`/api/v1/discovered-issues/${encodeURIComponent(id)}`),c=d.cluster||{},examples=c.examples||[],keys=Array.isArray(c.keywords)?c.keywords:[];$("cluster-modal-title").textContent=clusterTitle(c);detail.innerHTML=`<div class="detail-stats"><div><span>Cluster</span><strong>#${esc(c.cluster_id??id)}</strong></div><div><span>Size</span><strong>${num(c.size??c.count)}</strong></div><div><span>Coverage</span><strong>${c.coverage==null?"—":num(Number(c.coverage)*100,1)+"%"}</strong></div><div><span>Purity</span><strong>${c.purity==null?"—":num(c.purity,2)}</strong></div></div>${c.reference_label?`<div class="notice" style="margin-top:10px"><span class="notice-dot"></span>Reference field leader: <strong>${esc(c.reference_label)}</strong></div>`:""}<div class="detail-section"><div class="detail-label">Keywords</div><div class="keyword-list">${keys.map(k=>`<span class="keyword">${esc(k)}</span>`).join("")||"<span class='muted'>No keyword summary.</span>"}</div></div><div class="detail-section"><div class="detail-label">Representative examples</div><div class="examples-list">${examples.length?examples.map((e,i)=>`<div class="example-row"><span>${String(i+1).padStart(2,"0")}</span><p>${esc(e)}</p></div>`).join(""):"<div class='notice'>No examples were stored for this cluster.</div>"}</div></div>`}catch(e){detail.innerHTML=`<div class="error-box">${esc(e.message)}</div>`}}
function closeModal(){$("cluster-modal").classList.add("hidden");$("cluster-modal").setAttribute("aria-hidden","true")}

function init(){
  document.querySelectorAll("[data-target]").forEach(el=>el.addEventListener("click",()=>setView(el.dataset.target)));
  $("refresh-btn")?.addEventListener("click",()=>loadAll().then(()=>toast("Dashboard refreshed.")));
  $("analyze-btn")?.addEventListener("click",analyzeComplaint);
  $("complaint-input")?.addEventListener("input",e=>$("char-count").textContent=`${e.target.value.length} / 4000`);
  $("choose-file")?.addEventListener("click",()=>$("dataset-file").click());
  $("dataset-file")?.addEventListener("change",e=>handleFile(e.target.files[0]));
  $("upload-drop")?.addEventListener("click",e=>{if(!e.target.closest("button"))$("dataset-file").click()});
  $("upload-drop")?.addEventListener("dragover",e=>{e.preventDefault();$("upload-drop").classList.add("dragging")});
  $("upload-drop")?.addEventListener("dragleave",()=>$("upload-drop").classList.remove("dragging"));
  $("upload-drop")?.addEventListener("drop",e=>{e.preventDefault();$("upload-drop").classList.remove("dragging");handleFile(e.dataTransfer.files[0])});
  $("reset-dataset-btn")?.addEventListener("click",resetDataset);
  document.querySelectorAll("[data-close-modal]").forEach(el=>el.addEventListener("click",closeModal));
  document.addEventListener("keydown",e=>{if(e.key==="Escape")closeModal()});
  loadAll();
}
document.addEventListener("DOMContentLoaded",init);
