# Benchmark / Example Datasets

This directory contains example datasets used to demonstrate and test Customer Incident Intelligence.

These are **benchmark/demo inputs**, not proprietary or production customer records.

## 1. `customer-reviews-10000.csv`

Purpose:
- test autonomous text-field detection
- test semantic embeddings
- test unsupervised issue discovery
- test sentiment analysis
- test rating/evaluation-field detection

The dataset does not contain a reliable date/time field, so temporal trend monitoring is not expected for this file.

## 2. `lingrow_support_tickets.csv`

Purpose:
- test text + date ingestion
- test semantic discovery
- test sentiment analysis
- test temporal aggregation
- test surge/alert logic

This support-ticket dataset is synthetic and should be treated as a technical benchmark rather than real-world customer evidence.

## 3. BANKING77

BANKING77 is the project's known-label benchmark for semantic evaluation and clustering experiments. The application does not force arbitrary custom datasets into the BANKING77 taxonomy.

## Portfolio/demo datasets

These files are included so the repository can be demonstrated without proprietary customer data. They exercise different parts of the pipeline rather than serving as a single official benchmark.
