# Architecture

## Runtime components

### FastAPI application

`backend/app/main.py` owns:

- Web UI hosting
- dataset upload/validation
- automatic schema detection
- analysis jobs and progress state
- semantic embeddings
- dataset-local clustering
- issue naming
- sentiment inference
- temporal trend analysis
- surge alerts
- cluster evidence
- custom-dataset NLP analysis

### Semantic model

`all-MiniLM-L6-v2` converts each text row into a 384-dimensional embedding. Similar meanings occupy nearby regions in embedding space.

### Clustering

Custom datasets use dataset-local clustering rather than assuming BANKING77 labels. The goal is discovery: the system finds recurring semantic themes in the uploaded corpus.

### Sentiment

`sentiment-roberta-large-english-3-classes` provides positive, neutral, and negative inference.

### Trends and alerts

When a reliable date field exists, issue frequency can be aggregated over time and compared with a historical baseline. Alerts are statistical signals, not causal diagnoses.

## Benchmark isolation

BANKING77 is used as a known-label benchmark/reference workflow. Custom datasets are not forced into the BANKING77 taxonomy.

## Why there is no LLM in the core path

The project deliberately avoids depending on a generative LLM for the core analytics path. This keeps inference local, deterministic enough for a benchmark workflow, and focused on task-specific models plus classical statistical/ML methods.
