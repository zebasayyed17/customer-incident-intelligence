# Installation guide

## Supported setup

- Windows 10/11
- Python 3.12
- NVIDIA GPU recommended for practical inference speed
- 8 GB+ system RAM recommended; more is useful for larger files

## Fresh install

```powershell
cd C:\customer-incident-intelligence
Set-ExecutionPolicy -Scope Process Bypass
.\setup_windows.ps1
```

Then verify:

```powershell
.\.venv\Scripts\python.exe scripts\verify_environment.py
```

Install the Web UI dependencies:

```powershell
.\.venv\Scripts\python.exe -m pip install -r requirements-add.txt
```

Start:

```powershell
.\scripts\run_webui.ps1
```

## GPU check

The verification script should report:

- PyTorch installed
- CUDA available: `True`
- NVIDIA GPU name

The exact PyTorch CUDA wheel can change over time. If your environment installs a CPU-only wheel, use the official PyTorch Windows installation selector to install the CUDA build that matches your driver/toolchain.

## First model run

The first application run may download the pretrained Hugging Face models:

- `sentence-transformers/all-MiniLM-L6-v2`
- `j-hartmann/sentiment-roberta-large-english-3-classes`

Subsequent runs use the local cache.

## Web UI dependency repair

If startup reports a missing upload or Excel dependency:

```powershell
.\scripts\install_webui_requirements.ps1
```

## Troubleshooting

### Port 8000 already in use

Find the process:

```powershell
Get-NetTCPConnection -LocalPort 8000 -ErrorAction SilentlyContinue
```

Stop the process if appropriate, then restart the application.

### Browser shows an old interface

Use `Ctrl+F5`. The current Web UI also sends no-cache headers for the root page and versions static assets to reduce stale-browser problems.

### Trend monitoring says it is not applicable

The uploaded dataset does not contain a field that can be reliably interpreted as a date/time. The semantic, clustering, and sentiment stages can still run normally.

### No formal alerts

No formal alert is not automatically an error. A dated dataset can complete correctly and produce zero alerts when no issue satisfies the configured surge criteria.
