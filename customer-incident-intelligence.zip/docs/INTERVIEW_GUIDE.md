# Interview Guide

## 30-second explanation

Customer Incident Intelligence is an end-to-end NLP analytics platform. It accepts customer complaints, reviews, or support tickets, automatically identifies usable fields, converts text into MiniLM semantic embeddings, discovers recurring issue groups with unsupervised clustering, classifies sentiment with a pretrained RoBERTa model, and—when dates exist—monitors issue frequency against a historical baseline for statistical surge alerts. FastAPI exposes the pipeline through a lightweight web dashboard.

## Core mental model

```text
Customer text
  -> cleaning
  -> MiniLM embeddings (384-D)
  -> semantic clustering
  -> issue discovery
  -> RoBERTa sentiment
  -> optional time aggregation
  -> baseline / lift / z-score
  -> alerts
  -> FastAPI API
  -> Web UI
```

## Key interview questions

### Why embeddings?
Keyword matching misses semantic similarity when different phrases describe the same problem. Embeddings represent meaning in vector space so semantically related sentences can be compared by similarity.

### Why unsupervised clustering?
A new dataset may contain issue categories that were never defined in advance. Clustering lets the system discover recurring themes without forcing the data into a fixed taxonomy.

### Why separate sentiment from embeddings?
Topic discovery and sentiment are different tasks. MiniLM represents semantic meaning; the RoBERTa classifier predicts positive, neutral, or negative sentiment.

### What happens without a date column?
Issue discovery and sentiment still work. Only temporal trends and date-based alerts are unavailable.

### Is this root-cause analysis?
No. The system discovers and monitors issue patterns. Causal root-cause analysis would require additional process/business data and a different methodology.

### Why keep BANKING77 separate?
BANKING77 has known intent labels and is useful for benchmarking. Arbitrary custom datasets should not be incorrectly mapped into banking-specific labels.

### Why was HDBSCAN not used for the CFPB operational trend layer?
The experiments produced too much noise and overly broad clusters for that corpus. The project therefore used the structured CFPB issue taxonomy for the trend/alert layer instead of forcing unreliable semantic clusters into it.

## Claims to avoid

- Do not call NMI or ARI “accuracy”.
- Do not claim perfect sentiment classification.
- Do not claim causal root-cause detection.
- Do not present benchmark data as real production customer evidence.
- Do not invent accuracy metrics for unlabeled custom datasets.
