# Portfolio & LinkedIn Material

## One-line project description

**Customer Incident Intelligence — an end-to-end NLP analytics platform that discovers recurring customer issues, classifies sentiment, and detects unusual changes in issue volume.**

## GitHub About text

**End-to-end NLP analytics platform for semantic issue discovery, sentiment analysis, trend monitoring, and statistical incident alerts from customer text.**

## Suggested repository topics

```text
python
nlp
data-science
machine-learning
natural-language-processing
sentence-transformers
huggingface
pytorch
fastapi
unsupervised-learning
clustering
sentiment-analysis
anomaly-detection
customer-analytics
```

## Resume bullets

### Version A — data-science focused

- Built an end-to-end **NLP analytics platform** that converts customer reviews, complaints, and support tickets into semantic issue clusters, sentiment signals, and time-based incident alerts.
- Implemented **384-dimensional MiniLM embeddings**, unsupervised semantic clustering, and pretrained RoBERTa sentiment inference with PyTorch/CUDA acceleration.
- Designed an **automatic schema-detection pipeline** for heterogeneous CSV/XLSX/XLSM/XLS inputs, including text, date/time, and evaluation-field detection.
- Added a temporal monitoring layer using **historical baselines, lift, and z-score signals**, with explicit limitations around causal interpretation and public complaint datasets.
- Built a **FastAPI + HTML/CSS/JavaScript dashboard** with clickable cluster inspection and automatic dataset analysis; documented evaluation methodology and leakage checks using BANKING77.

### Version B — compact

- Built a dataset-independent NLP platform for **issue discovery, sentiment analysis, and incident trend detection** across reviews, complaints, and support tickets.
- Used **Sentence Transformers, unsupervised clustering, RoBERTa, Pandas, scikit-learn, PyTorch/CUDA, and FastAPI** in one end-to-end workflow.
- Added automatic schema inference, benchmark evaluation, statistical alerting, and a browser-based analytics dashboard.

## LinkedIn project description

Customer Incident Intelligence is an end-to-end NLP analytics project for turning unstructured customer text into actionable analytical signals.

The system automatically detects useful dataset fields, creates semantic embeddings with `all-MiniLM-L6-v2`, discovers recurring issue groups with unsupervised clustering, classifies sentiment with a pretrained RoBERTa model, and—when timestamps are available—compares recent issue volume against a historical baseline using lift and z-score signals.

The application is exposed through FastAPI and a lightweight web dashboard. BANKING77 is kept as a benchmark/reference workflow rather than being used as a fixed taxonomy for arbitrary datasets.

## Portfolio positioning

This should be presented as an **applied data-science project**, not just an NLP demo. The strongest story is the complete pipeline:

```text
messy data
  -> validation
  -> schema inference
  -> representation
  -> unsupervised discovery
  -> sentiment
  -> temporal analytics
  -> statistical alerting
  -> API
  -> dashboard
```

## What to explain in an interview

### Problem
Customer-support datasets contain large amounts of free-form text, but issue categories may be unknown or change over time.

### Approach
Represent text semantically, discover groups without predefined categories, layer sentiment analysis on top, and use dates—when available—to identify unusual changes in issue volume.

### Why it is not just a classifier
A fixed classifier requires a predefined label taxonomy. This project is designed to discover themes in datasets where the relevant categories are not known in advance.

### Why BANKING77 is separate
BANKING77 provides known intent labels useful for evaluation. A generic customer-support dataset should not be forced into a banking-specific label space.

### Main limitation
Clusters indicate recurring semantic patterns, not causal root causes. Trend alerts indicate an observed change in volume, not why the change happened.

## Claims to avoid

- Do not call NMI, ARI, purity, or coverage "accuracy".
- Do not claim causal root-cause detection.
- Do not claim that a custom unlabeled dataset has supervised accuracy.
- Do not present benchmark datasets as proprietary customer records.
- Do not describe statistical surge signals as proof of a business cause.
