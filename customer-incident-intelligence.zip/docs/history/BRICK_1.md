# Brick 1 — Model Foundation

## Objective

Prove that the two fixed pretrained models can run locally before we build clustering, topic discovery, trend detection, or the web UI.

### Model 1: semantic embeddings

`sentence-transformers/all-MiniLM-L6-v2`

- 384-dimensional sentence embeddings
- Used for clustering, semantic similarity, and retrieval
- No training required

### Model 2: sentiment

`cardiffnlp/twitter-roberta-base-sentiment-latest`

- Pretrained 3-way sentiment classifier
- Used only as a sentiment signal
- No training required

## Acceptance criteria

The smoke test must:

1. Load both models successfully.
2. Produce a `(3, 384)` embedding matrix.
3. Produce one sentiment prediction per sample.
4. Finish without model-loading errors.

Do not build the frontend or clustering layer until these checks pass.
