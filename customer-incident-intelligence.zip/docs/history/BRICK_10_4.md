# Brick 10.4 — Universal Dataset Engine

## Fixed
- HTML/CSS/JS are shipped as one coherent frontend bundle.
- Removed stale field-selector/analyze-button dependencies from JavaScript.
- Dataset upload automatically detects schema and starts analysis.
- Dashboard always renders source rows, analyzed rows, cluster count, sentiment mix, date coverage, alerts, notes, and detected schema.
- Custom datasets use their own discovered semantic clusters in the NLP Analyzer; BANKING77 is isolated to benchmark mode.
- Trend and formal-alert views now show explicit "not applicable"/"no signal" states instead of blank panels.
- Cluster evidence remains clickable.
- Upload progress is tied to real backend job stages.
- Automatic date/evaluation field detection is more robust.
- Large datasets receive a deterministic ML safety sample with transparent reporting.
- Static assets use cache-busting query strings and root HTML is no-store to prevent stale frontend code.

## Runtime
Run from the real project root:

```powershell
cd C:\customer-incident-intelligence
.\scripts\run_webui.ps1
```

Then open `http://127.0.0.1:8000/` and press `Ctrl+F5` once.
