# Brick 2 — Dataset Ingestion

This brick downloads and validates the official BANKING77 train/test CSV files.

Source:
- https://github.com/PolyAI-LDN/task-specific-datasets
- https://huggingface.co/datasets/PolyAI/banking77

Dataset:
- 10,003 training examples
- 3,080 test examples
- 77 intent categories
- English customer-service queries
- License: CC BY 4.0

The scripts intentionally download the source CSV files directly instead of using
the Hugging Face `datasets` loader. This avoids compatibility problems with the
legacy dataset loading script while preserving the official source data.

## Run

From the project root:

```powershell
.\.venv\Scripts\python.exe scripts\download_banking77.py
.\.venv\Scripts\python.exe scripts\validate_dataset.py
```

Expected final lines:

```text
BRICK 2 DOWNLOAD: PASS
BRICK 2 VALIDATION: PASS
```
