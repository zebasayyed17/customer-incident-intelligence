# Brick 3 — Dataset Profiling & Leakage Check

This brick inspects BANKING77 before modeling.

It checks:
- train/test row counts
- number of categories
- duplicate rows within each split
- text length statistics
- category distribution
- exact text overlap between train and test
- representative examples

The most important check is train/test exact-text overlap. If exact customer messages occur
in both splits, a model can appear stronger than it really is because it has effectively seen
the same example during training and evaluation.

## Run

From the project root:

```powershell
.\.venv\Scripts\python.exe scripts\profile_banking77.py
.\.venv\Scripts\python.exe scripts\inspect_examples.py
```

The profile report is written to:

```text
data\reports\dataset_profile.json
```

Expected:
- profile command ends with `BRICK 3 PROFILE: PASS`
- no exact train/test text overlap
- example inspection ends with `BRICK 3 EXAMPLE INSPECTION: PASS`

Do not change the raw CSV files.
