# Brick 4 — Semantic Embeddings

This brick uses the pretrained `sentence-transformers/all-MiniLM-L6-v2` model
to convert BANKING77 text into normalized 384-dimensional semantic vectors.

It does not train MiniLM.

## Pipeline

```text
BANKING77 text
     ↓
MiniLM
     ↓
384D normalized embedding
     ↓
semantic similarity / clustering / retrieval
```

## Run

First generate embeddings:

```powershell
.\.venv\Scripts\python.exe scripts\generate_embeddings.py
```

Then run the diagnostic quality probe:

```powershell
.\.venv\Scripts\python.exe scripts\validate_embeddings.py
```

The quality probe uses a cosine-similarity nearest-centroid diagnostic:
- compute one centroid per known intent using the training embeddings
- assign each de-leaked evaluation example to the closest centroid
- report accuracy

This is not the final classifier. It is a sanity check that MiniLM's semantic
space contains useful signal for the 77 BANKING77 intents.

Outputs:
- `data/processed/train_embeddings.npy`
- `data/processed/evaluation_embeddings.npy`
- `data/processed/train_labels.json`
- `data/processed/evaluation_labels.json`
- `data/reports/embedding_generation.json`
- `data/reports/embedding_quality.json`
