# Brick 5 — Unsupervised Issue Discovery

This brick asks a different question from Brick 4.

Brick 4:
- "Does MiniLM's semantic space contain useful intent information?"

Brick 5:
- "Can we discover coherent groups WITHOUT giving the clustering algorithm the BANKING77 labels?"

## Algorithm

HDBSCAN is run on the 384D MiniLM embeddings from the training split.

Labels are completely excluded from cluster formation.

After clustering, labels are used only for diagnostics:
- Adjusted Rand Index (ARI)
- Normalized Mutual Information (NMI)
- mean cluster purity

This lets us evaluate the unsupervised result without leaking labels into the clustering process.

## Run

Install the one new dependency:

```powershell
.\.venv\Scripts\python.exe -m pip install "hdbscan>=0.8.41,<0.9"
```

Then:

```powershell
.\.venv\Scripts\python.exe scripts\cluster_embeddings.py
.\.venv\Scripts\python.exe scripts\evaluate_clusters.py
.\.venv\Scripts\python.exe scripts\inspect_clusters.py
```

Outputs:
- `data/processed/train_cluster_ids.npy`
- `data/reports/hdbscan_clustering.json`
- `data/reports/cluster_quality.json`
- `data/reports/cluster_examples.json`

The dominant known intent shown during inspection is diagnostic only. It is NOT used to form the cluster.
