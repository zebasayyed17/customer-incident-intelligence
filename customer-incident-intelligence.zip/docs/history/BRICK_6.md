# Brick 6 — Sentiment Layer

This brick applies the pretrained sentiment classifier to BANKING77 complaints.

Model:
`cardiffnlp/twitter-roberta-base-sentiment-latest`

It produces:
- row-level sentiment predictions
- confidence
- sentiment distributions per discovered cluster
- a list of the most negative clusters

## Important limitation

BANKING77 does not contain human sentiment labels. Therefore this brick does NOT claim
sentiment accuracy on BANKING77.

The sentiment outputs are treated as an exploratory business signal.

For a production-quality portfolio claim, the sentiment model should later be evaluated
on a separately labeled sentiment dataset or on a human-annotated sample from the target
domain.

## Run

```powershell
.\.venv\Scripts\python.exe scripts\analyze_sentiment.py
```

Expected outputs:
- `data/processed/train_sentiment_predictions.csv`
- `data/reports/sentiment_profile.json`
- `data/reports/sentiment_cluster_summary.csv`

The model can use the RTX 4050 and falls back to CPU automatically.
