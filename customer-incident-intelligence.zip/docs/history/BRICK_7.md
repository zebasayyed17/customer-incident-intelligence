# Brick 7 — Timestamped Incident Dataset

BANKING77 is excellent for semantic discovery, but it has no complaint timestamps.
We therefore add an official, timestamped source for the trend-detection portion.

Source:
CFPB Consumer Complaint Database narrative archive.

The CFPB documents a `Date received` field and other complaint metadata. The narrative
archive contains complaints published through August 14, 2026. The Bureau announced on
August 14, 2026 that it was ceasing discretionary publication of unverified complaint
narratives and visualizations, so this brick intentionally uses archived data through that
date rather than pretending narratives continue after it.

We download:
- May 2026
- June 2026
- July 2026
- August 2026

Then we build a focused incident dataset with:
- complaint_id
- date_received
- product
- issue
- sub_issue
- company
- text
- source_archive

## Run

```powershell
.\.venv\Scripts\python.exe scripts\download_cfpb_archives.py
```

Then:

```powershell
.\.venv\Scripts\python.exe scripts\build_cfpb_trend_dataset.py
```

The final dataset is:

```text
data\processed\cfpb_incidents.csv
```

The profile is:

```text
data\reports\cfpb_trend_dataset_profile.json
```

Do not edit the downloaded archives or the processed dataset by hand.
