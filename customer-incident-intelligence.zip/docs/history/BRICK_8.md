# Brick 8 — Timestamped Incident Discovery + Trend Detection

This brick moves from a static benchmark to an actual incident-monitoring workflow.

## Step 1 — Coverage audit

```powershell
.\.venv\Scripts\python.exe scripts\audit_cfpb_coverage.py
```

## Step 2 — Discover issues

The 20,149 CFPB narratives are embedded with MiniLM and clustered with the selected
HDBSCAN configuration (min_cluster_size=20, min_samples=5).

```powershell
.\.venv\Scripts\python.exe scripts\cluster_cfpb_incidents.py
```

## Step 3 — Detect unusual recent growth

The system computes:
- current 7-day complaint count per cluster
- expected 7-day count based on the preceding 28-day baseline
- lift
- a Poisson-like z-score
- an alert when all configured thresholds are met

```powershell
.\.venv\Scripts\python.exe scripts\detect_incident_trends.py
```

This is an operational anomaly score, not a statistical claim that a problem is
"significant" in the broader population.

## Outputs

- `data/reports/cfpb_coverage_audit.json`
- `data/processed/cfpb_embeddings.npy`
- `data/processed/cfpb_cluster_ids.npy`
- `data/reports/cfpb_issue_discovery.json`
- `data/reports/cfpb_issue_trend_scores.csv`

## Interpretation

The CFPB notes that its published complaint data are not a statistical sample of
consumer experiences. Therefore dashboard language should say:
- "complaint volume"
- "emerging complaint cluster"
- "observed increase"

and should not say:
- "prevalence"
- "market-wide incidence"
- "the bank has caused X% of consumer harm"

The source is an archived public complaint dataset whose narratives are opt-in/publicly
released and PII-scrubbed; it should be treated as a signal for incident discovery.
