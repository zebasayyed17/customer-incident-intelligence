from __future__ import annotations

import csv
import json
from collections import Counter, defaultdict
from pathlib import Path

import numpy as np
import torch
from transformers import pipeline

ROOT = Path(__file__).resolve().parents[1]
RAW = ROOT / "data" / "raw"
PROCESSED = ROOT / "data" / "processed"
REPORTS = ROOT / "data" / "reports"
REPORTS.mkdir(parents=True, exist_ok=True)

MODEL_NAME = "cardiffnlp/twitter-roberta-base-sentiment-latest"
BATCH_SIZE = 32

def load_rows() -> list[dict[str, str]]:
    with (RAW / "train.csv").open("r", encoding="utf-8", newline="") as f:
        return list(csv.DictReader(f))

def load_topics() -> dict[int, dict]:
    path = REPORTS / "discovered_issue_topics_v2.json"
    if not path.exists():
        return {}
    data = json.loads(path.read_text(encoding="utf-8"))
    return {int(x["cluster_id"]): x for x in data["clusters"]}

def main() -> None:
    rows = load_rows()
    cluster_ids = np.load(PROCESSED / "train_cluster_ids.npy")

    if len(rows) != len(cluster_ids):
        raise RuntimeError("Training rows and cluster IDs have different lengths.")

    device = 0 if torch.cuda.is_available() else -1

    print("=== SENTIMENT INFERENCE ===")
    print(f"Model:  {MODEL_NAME}")
    print(f"Device: {'cuda:0' if device == 0 else 'cpu'}")
    if device == 0:
        print(f"GPU:    {torch.cuda.get_device_name(0)}")

    classifier = pipeline(
        "sentiment-analysis",
        model=MODEL_NAME,
        tokenizer=MODEL_NAME,
        device=device,
    )

    texts = [row["text"] for row in rows]
    predictions = classifier(
        texts,
        batch_size=BATCH_SIZE,
        truncation=True,
        max_length=128,
    )

    label_map = {
        "LABEL_0": "negative",
        "LABEL_1": "neutral",
        "LABEL_2": "positive",
    }

    row_records = []
    cluster_agg: dict[int, Counter] = defaultdict(Counter)
    cluster_conf: dict[int, list[float]] = defaultdict(list)

    overall = Counter()
    low_confidence = 0

    for row, cid, pred in zip(rows, cluster_ids, predictions):
        label = label_map.get(str(pred["label"]), str(pred["label"]).lower())
        confidence = float(pred["score"])

        if confidence < 0.70:
            low_confidence += 1

        overall[label] += 1
        cluster_agg[int(cid)][label] += 1
        cluster_conf[int(cid)].append(confidence)

        row_records.append({
            "text": row["text"],
            "category": row["category"],
            "cluster_id": int(cid),
            "sentiment": label,
            "confidence": round(confidence, 6),
        })

    # Row-level output for inspection and later analytics.
    row_path = PROCESSED / "train_sentiment_predictions.csv"
    with row_path.open("w", encoding="utf-8", newline="") as f:
        writer = csv.DictWriter(
            f,
            fieldnames=["text", "category", "cluster_id", "sentiment", "confidence"],
        )
        writer.writeheader()
        writer.writerows(row_records)

    topics = load_topics()
    cluster_records = []

    for cid, counts in cluster_agg.items():
        total = sum(counts.values())
        record = {
            "cluster_id": cid,
            "size": total,
            "candidate_label": topics.get(cid, {}).get("candidate_label"),
            "negative": counts["negative"],
            "neutral": counts["neutral"],
            "positive": counts["positive"],
            "negative_rate": round(counts["negative"] / total, 4),
            "neutral_rate": round(counts["neutral"] / total, 4),
            "positive_rate": round(counts["positive"] / total, 4),
            "mean_confidence": round(float(np.mean(cluster_conf[cid])), 4),
            "low_confidence_rate": round(
                float(np.mean(np.array(cluster_conf[cid]) < 0.70)), 4
            ),
        }
        cluster_records.append(record)

    cluster_records.sort(
        key=lambda x: (x["negative_rate"], x["size"]),
        reverse=True,
    )

    overall_total = sum(overall.values())
    report = {
        "model": MODEL_NAME,
        "model_note": (
            "Pretrained Twitter-domain RoBERTa sentiment model. "
            "These are exploratory sentiment signals for BANKING77, not a "
            "domain-validated accuracy claim."
        ),
        "rows_analyzed": len(rows),
        "overall": {
            "negative": overall["negative"],
            "neutral": overall["neutral"],
            "positive": overall["positive"],
            "negative_rate": round(overall["negative"] / overall_total, 4),
            "neutral_rate": round(overall["neutral"] / overall_total, 4),
            "positive_rate": round(overall["positive"] / overall_total, 4),
            "low_confidence_count": low_confidence,
            "low_confidence_rate": round(low_confidence / overall_total, 4),
        },
        "clusters": cluster_records,
    }

    (REPORTS / "sentiment_profile.json").write_text(
        json.dumps(report, indent=2, ensure_ascii=False),
        encoding="utf-8",
    )

    with (REPORTS / "sentiment_cluster_summary.csv").open(
        "w", encoding="utf-8", newline=""
    ) as f:
        fields = [
            "cluster_id", "size", "candidate_label",
            "negative", "neutral", "positive",
            "negative_rate", "neutral_rate", "positive_rate",
            "mean_confidence", "low_confidence_rate",
        ]
        writer = csv.DictWriter(f, fieldnames=fields)
        writer.writeheader()
        writer.writerows(cluster_records)

    print("\n=== SENTIMENT SUMMARY ===")
    print(f"Rows analyzed: {len(rows):,}")
    print(f"Negative:      {overall['negative']:,} ({overall['negative']/overall_total:.1%})")
    print(f"Neutral:       {overall['neutral']:,} ({overall['neutral']/overall_total:.1%})")
    print(f"Positive:      {overall['positive']:,} ({overall['positive']/overall_total:.1%})")
    print(
        f"Low confidence (<0.70): {low_confidence:,} "
        f"({low_confidence/overall_total:.1%})"
    )

    print("\nMost negative discovered clusters:")
    for item in cluster_records[:10]:
        print(
            f"  Cluster {item['cluster_id']:>3} | "
            f"{item['size']:>3} rows | "
            f"negative={item['negative_rate']:.1%} | "
            f"{item['candidate_label'] or '[no label]'}"
        )

    print(f"\nRow predictions: {row_path}")
    print(f"Report:          {REPORTS / 'sentiment_profile.json'}")
    print(f"Cluster summary: {REPORTS / 'sentiment_cluster_summary.csv'}")
    print("\nBRICK 6: PASS")

if __name__ == "__main__":
    main()
