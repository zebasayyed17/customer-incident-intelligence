from __future__ import annotations

import json
from pathlib import Path

import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
DATA = ROOT / "data" / "processed" / "cfpb_incidents.csv"
REPORTS = ROOT / "data" / "reports"

def main() -> None:
    if not DATA.exists():
        raise FileNotFoundError("Run Brick 7 first.")

    df = pd.read_csv(DATA, parse_dates=["date_received"])

    if df.empty:
        raise RuntimeError("CFPB incident dataset is empty.")

    duplicate_ids = int(df["complaint_id"].duplicated().sum())
    null_dates = int(df["date_received"].isna().sum())
    null_text = int(df["text"].fillna("").str.strip().eq("").sum())

    monthly = (
        df.assign(month=df["date_received"].dt.to_period("M").astype(str))
        .groupby("month")
        .size()
        .to_dict()
    )

    by_archive = (
        df.groupby("source_archive")
        .agg(
            rows=("text", "size"),
            min_date=("date_received", "min"),
            max_date=("date_received", "max"),
        )
        .reset_index()
    )

    by_archive["min_date"] = by_archive["min_date"].dt.strftime("%Y-%m-%d")
    by_archive["max_date"] = by_archive["max_date"].dt.strftime("%Y-%m-%d")

    report = {
        "rows": len(df),
        "date_min": df["date_received"].min().strftime("%Y-%m-%d"),
        "date_max": df["date_received"].max().strftime("%Y-%m-%d"),
        "duplicate_complaint_ids": duplicate_ids,
        "null_dates": null_dates,
        "empty_text": null_text,
        "monthly_counts": monthly,
        "archive_coverage": by_archive.to_dict(orient="records"),
    }

    REPORTS.mkdir(parents=True, exist_ok=True)
    (REPORTS / "cfpb_coverage_audit.json").write_text(
        json.dumps(report, indent=2, default=str),
        encoding="utf-8",
    )

    print("=== CFPB COVERAGE AUDIT ===")
    print(f"Rows:              {len(df):,}")
    print(f"Date range:        {report['date_min']} to {report['date_max']}")
    print(f"Duplicate IDs:     {duplicate_ids}")
    print(f"Null dates:        {null_dates}")
    print(f"Empty narratives:  {null_text}")

    print("\nMonthly counts:")
    for month, count in sorted(monthly.items()):
        print(f"  {month}: {count:,}")

    print("\nArchive coverage:")
    for item in report["archive_coverage"]:
        print(
            f"  {item['source_archive']}: {item['rows']:,} rows | "
            f"{item['min_date']} -> {item['max_date']}"
        )

    if duplicate_ids or null_dates or null_text:
        raise RuntimeError("CFPB coverage audit found data-quality issues.")

    print(f"\nReport: {REPORTS / 'cfpb_coverage_audit.json'}")
    print("\nBRICK 8 COVERAGE AUDIT: PASS")

if __name__ == "__main__":
    main()
