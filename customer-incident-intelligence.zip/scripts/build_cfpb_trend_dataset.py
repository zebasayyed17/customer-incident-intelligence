from __future__ import annotations

import csv
import re
import zipfile
from pathlib import Path

import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
RAW = ROOT / "data" / "cfpb_raw"
PROCESSED = ROOT / "data" / "processed"
REPORTS = ROOT / "data" / "reports"

OUTPUT = PROCESSED / "cfpb_incidents.csv"

TARGET_PRODUCTS = {
    "Checking or savings account",
    "Credit card or prepaid card",
    "Money transfer, virtual currency, or money service",
    "Bank account or service",
    "Credit card",
    "Prepaid card",
}

def find_csv_members(zf: zipfile.ZipFile) -> list[str]:
    return [
        name for name in zf.namelist()
        if name.lower().endswith(".csv") and not name.endswith("/")
    ]

def resolve_column(columns: list[str], candidates: list[str]) -> str | None:
    normalized = {re.sub(r"\s+", " ", c.strip().lower()): c for c in columns}
    for candidate in candidates:
        key = re.sub(r"\s+", " ", candidate.strip().lower())
        if key in normalized:
            return normalized[key]
    return None

def load_archive(path: Path) -> pd.DataFrame:
    with zipfile.ZipFile(path) as zf:
        csvs = find_csv_members(zf)
        if not csvs:
            raise RuntimeError(f"No CSV found in {path.name}")

        # Prefer the largest CSV if an archive contains metadata files.
        csvs.sort(key=lambda n: zf.getinfo(n).file_size, reverse=True)
        member = csvs[0]

        with zf.open(member) as fh:
            return pd.read_csv(fh, low_memory=False)

def main() -> None:
    archives = sorted(RAW.glob("CCDB_*.zip"))
    if not archives:
        raise FileNotFoundError(
            "No CFPB archives found. Run download_cfpb_archives.py first."
        )

    frames = []
    for archive in archives:
        print(f"Reading {archive.name} ...")
        frame = load_archive(archive)
        frame["source_archive"] = archive.name
        frames.append(frame)
        print(f"  Rows: {len(frame):,}")

    df = pd.concat(frames, ignore_index=True)

    date_col = resolve_column(
        list(df.columns),
        ["Date received", "date_received"],
    )
    narrative_col = resolve_column(
        list(df.columns),
        [
            "Consumer complaint narrative",
            "consumer_complaint_narrative",
            "Complaint narrative",
        ],
    )
    product_col = resolve_column(
        list(df.columns),
        ["Product", "product"],
    )
    issue_col = resolve_column(
        list(df.columns),
        ["Issue", "issue"],
    )
    subissue_col = resolve_column(
        list(df.columns),
        ["Sub-issue", "sub_issue", "subissue"],
    )
    company_col = resolve_column(
        list(df.columns),
        ["Company", "company"],
    )
    id_col = resolve_column(
        list(df.columns),
        ["Complaint ID", "complaint_id"],
    )

    required = {
        "date": date_col,
        "narrative": narrative_col,
        "product": product_col,
    }
    missing = [k for k, v in required.items() if v is None]
    if missing:
        raise RuntimeError(
            f"Could not resolve required columns: {missing}. "
            f"Available columns: {list(df.columns)}"
        )

    out = pd.DataFrame({
        "complaint_id": df[id_col] if id_col else range(len(df)),
        "date_received": pd.to_datetime(df[date_col], errors="coerce"),
        "product": df[product_col].fillna("").astype(str),
        "issue": df[issue_col].fillna("").astype(str) if issue_col else "",
        "sub_issue": df[subissue_col].fillna("").astype(str) if subissue_col else "",
        "company": df[company_col].fillna("").astype(str) if company_col else "",
        "text": df[narrative_col].fillna("").astype(str),
        "source_archive": df["source_archive"],
    })

    # Keep published narratives only; blanks are not usable for NLP.
    out = out[out["text"].str.strip().ne("")].copy()

    # Focus the first trend dataset on bank/card/payment-like products.
    if TARGET_PRODUCTS:
        filtered = out[out["product"].isin(TARGET_PRODUCTS)].copy()
        # If the archive uses different historical product wording, retain the larger
        # published narrative set rather than silently producing an empty dataset.
        if len(filtered) >= 1000:
            out = filtered

    out["date_received"] = out["date_received"].dt.strftime("%Y-%m-%d")
    out = out.drop_duplicates(subset=["complaint_id", "text"])
    out = out.sort_values("date_received")

    PROCESSED.mkdir(parents=True, exist_ok=True)
    REPORTS.mkdir(parents=True, exist_ok=True)

    out.to_csv(OUTPUT, index=False, encoding="utf-8")

    profile = {
        "rows": int(len(out)),
        "date_min": out["date_received"].min() if len(out) else None,
        "date_max": out["date_received"].max() if len(out) else None,
        "products": out["product"].value_counts().to_dict(),
        "issues": out["issue"].value_counts().head(20).to_dict(),
        "duplicates_removed": int(
            df[narrative_col].fillna("").astype(str).str.strip().ne("").sum() - len(out)
        ),
        "source_archives": sorted(out["source_archive"].dropna().unique().tolist()),
    }

    import json
    (REPORTS / "cfpb_trend_dataset_profile.json").write_text(
        json.dumps(profile, indent=2, ensure_ascii=False),
        encoding="utf-8",
    )

    print("\n=== CFPB TREND DATASET ===")
    print(f"Rows:       {len(out):,}")
    print(f"Date range: {out['date_received'].min()} to {out['date_received'].max()}")
    print("\nTop products:")
    for product, count in out["product"].value_counts().head(10).items():
        print(f"  {product}: {count:,}")

    print(f"\nOutput: {OUTPUT}")
    print(f"Profile: {REPORTS / 'cfpb_trend_dataset_profile.json'}")
    print("\nBRICK 7 BUILD: PASS")

if __name__ == "__main__":
    main()
