from __future__ import annotations

import csv
import json
import re
import time
from pathlib import Path

import hdbscan
import numpy as np
import pandas as pd
import torch
from sentence_transformers import SentenceTransformer
from sklearn.feature_extraction.text import CountVectorizer, TfidfTransformer

ROOT = Path(__file__).resolve().parents[1]
DATA = ROOT / "data" / "processed" / "cfpb_incidents.csv"
PROCESSED = ROOT / "data" / "processed"
REPORTS = ROOT / "data" / "reports"

MODEL_NAME = "sentence-transformers/all-MiniLM-L6-v2"
MIN_CLUSTER_SIZE = 20
MIN_SAMPLES = 5

STOPWORDS = {
    "a","an","and","are","as","at","be","been","but","by","can","could",
    "did","do","does","for","from","get","got","had","has","have","he",
    "her","here","how","i","if","in","is","it","its","me","my","of","on",
    "or","our","please","so","that","the","their","there","this","to",
    "was","we","what","when","where","which","who","why","will","with",
    "would","you","your","im","ive","dont","didnt","cant","couldnt",
    "wont","isnt","wasnt","they","them","theyre","also","just","help",
    "want","need","like","know",
}

GENERIC = {
    "bank","banking","account","money","issue","problem","question",
    "help","customer","service","complaint","company",
}

def clean_text(text: str) -> str:
    text = text.lower()
    text = re.sub(r"[^a-z0-9\s]", " ", text)
    return " ".join(
        token for token in text.split()
        if len(token) >= 3 and token not in STOPWORDS
    )

def main() -> None:
    df = pd.read_csv(DATA)
    if df.empty:
        raise RuntimeError("CFPB dataset is empty.")

    texts = df["text"].fillna("").astype(str).tolist()

    device = "cuda" if torch.cuda.is_available() else "cpu"
    batch = 64 if device == "cuda" else 32

    print("=== CFPB SEMANTIC INCIDENT DISCOVERY ===")
    print(f"Rows:      {len(texts):,}")
    print(f"Model:     {MODEL_NAME}")
    print(f"Device:    {device}")
    print(f"Batch:     {batch}")

    model = SentenceTransformer(MODEL_NAME, device=device)

    start = time.perf_counter()
    embeddings = model.encode(
        texts,
        batch_size=batch,
        show_progress_bar=True,
        normalize_embeddings=True,
        convert_to_numpy=True,
    ).astype(np.float32)

    embedding_time = time.perf_counter() - start
    np.save(PROCESSED / "cfpb_embeddings.npy", embeddings)

    print(f"\nEmbedding shape: {embeddings.shape}")
    print(f"Embedding time:  {embedding_time:.2f}s")

    print("\nRunning HDBSCAN...")
    start = time.perf_counter()

    clusterer = hdbscan.HDBSCAN(
        min_cluster_size=MIN_CLUSTER_SIZE,
        min_samples=MIN_SAMPLES,
        metric="euclidean",
        cluster_selection_method="eom",
        prediction_data=True,
        core_dist_n_jobs=-1,
    )
    cluster_ids = clusterer.fit_predict(embeddings)
    probabilities = clusterer.probabilities_

    clustering_time = time.perf_counter() - start

    np.save(PROCESSED / "cfpb_cluster_ids.npy", cluster_ids)
    np.save(PROCESSED / "cfpb_cluster_probabilities.npy", probabilities)

    non_noise = cluster_ids != -1
    cluster_count = len(set(cluster_ids) - {-1})
    noise = int((~non_noise).sum())

    cluster_members = {
        int(cid): np.where(cluster_ids == cid)[0]
        for cid in sorted(set(cluster_ids) - {-1})
    }

    docs = []
    cids = []
    for cid, indices in cluster_members.items():
        docs.append(" ".join(clean_text(texts[i]) for i in indices))
        cids.append(cid)

    candidate_labels = {}
    if docs:
        vectorizer = CountVectorizer(
            ngram_range=(1, 3),
            min_df=2,
            max_df=0.98,
            token_pattern=r"(?u)\b[a-zA-Z][a-zA-Z0-9]+\b",
        )
        counts = vectorizer.fit_transform(docs)
        tfidf = TfidfTransformer(
            use_idf=True,
            smooth_idf=True,
            sublinear_tf=True,
            norm=None,
        ).fit_transform(counts)
        terms = np.array(vectorizer.get_feature_names_out())

        for row_idx, cid in enumerate(cids):
            scores = tfidf[row_idx].toarray().ravel()
            ranked = np.argsort(scores)[::-1]
            phrases = []
            seen = set()

            for idx in ranked:
                phrase = terms[idx]
                tokens = phrase.split()
                if any(t in STOPWORDS for t in tokens):
                    continue
                if all(t in GENERIC for t in tokens):
                    continue
                if phrase in seen:
                    continue

                # Prefer 2-3 word phrases, but allow useful single terms.
                score = float(scores[idx]) * (1.12 if len(tokens) >= 2 else 1.0)
                phrases.append((phrase, score))
                seen.add(phrase)

                if len(phrases) >= 8:
                    break

            candidate_labels[cid] = " + ".join(p for p, _ in phrases[:2])

    records = []
    for cid, indices in cluster_members.items():
        record = {
            "cluster_id": cid,
            "size": int(len(indices)),
            "average_confidence": round(float(probabilities[indices].mean()), 4),
            "candidate_label": candidate_labels.get(cid, ""),
            "sample_texts": [texts[i] for i in indices[:5]],
        }
        records.append(record)

    records.sort(key=lambda x: x["size"], reverse=True)

    report = {
        "embedding_model": MODEL_NAME,
        "hdbscan_parameters": {
            "min_cluster_size": MIN_CLUSTER_SIZE,
            "min_samples": MIN_SAMPLES,
        },
        "rows": len(texts),
        "embedding_dimensions": int(embeddings.shape[1]),
        "clusters": cluster_count,
        "noise_rows": noise,
        "coverage": round(float(non_noise.mean()), 4),
        "embedding_seconds": round(embedding_time, 3),
        "clustering_seconds": round(clustering_time, 3),
        "cluster_summaries": records[:100],
    }

    (REPORTS / "cfpb_issue_discovery.json").write_text(
        json.dumps(report, indent=2, ensure_ascii=False),
        encoding="utf-8",
    )

    print("\n=== DISCOVERY SUMMARY ===")
    print(f"Clusters:  {cluster_count}")
    print(f"Noise:     {noise:,} ({noise/len(texts):.1%})")
    print(f"Coverage:  {non_noise.mean():.1%}")
    print(f"Cluster time: {clustering_time:.2f}s")

    print("\nLargest discovered issues:")
    for record in records[:15]:
        print(
            f"  Cluster {record['cluster_id']:>3} | "
            f"{record['size']:>4} rows | "
            f"{record['candidate_label'] or '[no label]'}"
        )

    print(f"\nReport: {REPORTS / 'cfpb_issue_discovery.json'}")
    print("\nBRICK 8 DISCOVERY: PASS")

if __name__ == "__main__":
    main()
