from __future__ import annotations

import json
import time
from pathlib import Path

import hdbscan
import numpy as np

ROOT = Path(__file__).resolve().parents[1]
PROCESSED = ROOT / "data" / "processed"
REPORTS = ROOT / "data" / "reports"

MODEL = "sentence-transformers/all-MiniLM-L6-v2"

def main() -> None:
    emb_path = PROCESSED / "train_embeddings.npy"
    labels_path = PROCESSED / "train_labels.json"

    if not emb_path.exists():
        raise FileNotFoundError(
            "Missing train_embeddings.npy. Run Brick 4 first."
        )

    X = np.load(emb_path).astype(np.float32)
    labels = json.loads(labels_path.read_text(encoding="utf-8"))

    if X.ndim != 2 or X.shape[1] != 384:
        raise RuntimeError(f"Expected (n, 384) embeddings, got {X.shape}")

    print("=== HDBSCAN CLUSTERING ===")
    print(f"Samples: {len(X):,}")
    print(f"Dimensions: {X.shape[1]}")
    print("Clustering on embeddings only; category labels are NOT used.")

    start = time.perf_counter()
    clusterer = hdbscan.HDBSCAN(
        min_cluster_size=35,
        min_samples=10,
        metric="euclidean",
        cluster_selection_method="eom",
        prediction_data=True,
        core_dist_n_jobs=-1,
    )

    cluster_ids = clusterer.fit_predict(X)
    elapsed = time.perf_counter() - start

    unique_clusters = sorted(set(cluster_ids) - {-1})
    noise = int(np.sum(cluster_ids == -1))

    counts = {
        str(int(cid)): int(np.sum(cluster_ids == cid))
        for cid in unique_clusters
    }

    report = {
        "embedding_model": MODEL,
        "algorithm": "HDBSCAN",
        "parameters": {
            "min_cluster_size": 35,
            "min_samples": 10,
            "metric": "euclidean",
            "cluster_selection_method": "eom",
        },
        "samples": int(len(X)),
        "dimensions": int(X.shape[1]),
        "clusters_found": len(unique_clusters),
        "noise_points": noise,
        "noise_fraction": round(noise / len(X), 4),
        "runtime_seconds": round(elapsed, 3),
        "largest_clusters": sorted(
            counts.items(), key=lambda item: item[1], reverse=True
        )[:20],
        "median_cluster_size": int(
            np.median(list(counts.values())) if counts else 0
        ),
    }

    np.save(PROCESSED / "train_cluster_ids.npy", cluster_ids)

    REPORTS.mkdir(parents=True, exist_ok=True)
    (REPORTS / "hdbscan_clustering.json").write_text(
        json.dumps(report, indent=2),
        encoding="utf-8",
    )

    print(f"\nClusters found: {len(unique_clusters)}")
    print(f"Noise points:    {noise:,} ({noise / len(X):.1%})")
    print(f"Runtime:         {elapsed:.2f}s")

    print("\nLargest clusters:")
    for cid, count in report["largest_clusters"][:10]:
        print(f"  Cluster {cid:>4}: {count:>4} rows")

    print("\nBRICK 5 CLUSTERING: PASS")

if __name__ == "__main__":
    main()
