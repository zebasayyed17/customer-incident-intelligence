from __future__ import annotations

import json
from pathlib import Path

import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
DATA = ROOT / "data" / "processed" / "cfpb_incidents.csv"
PROCESSED = ROOT / "data" / "processed"
REPORTS = ROOT / "data" / "reports"

MIN_CURRENT_COUNT = 10
MIN_LIFT = 1.5
MIN_Z = 2.0

def main() -> None:
    df = pd.read_csv(DATA, parse_dates=["date_received"])
    cluster_ids = np.load(PROCESSED / "cfpb_cluster_ids.npy")

    if len(df) != len(cluster_ids):
        raise RuntimeError("CFPB rows and cluster IDs have different lengths.")

    labels = json.loads(
        (REPORTS / "cfpb_issue_discovery.json").read_text(encoding="utf-8")
    )
    label_map = {
        int(x["cluster_id"]): x.get("candidate_label", "")
        for x in labels["cluster_summaries"]
    }

    df["cluster_id"] = cluster_ids
    df = df[df["cluster_id"] != -1].copy()

    if df.empty:
        raise RuntimeError("No non-noise CFPB clusters available.")

    # Daily counts per cluster.
    daily = (
        df.groupby(["date_received", "cluster_id"])
        .size()
        .rename("count")
        .reset_index()
    )

    all_dates = pd.date_range(
        daily["date_received"].min(),
        daily["date_received"].max(),
        freq="D",
    )
    all_clusters = sorted(daily["cluster_id"].unique())

    grid = pd.MultiIndex.from_product(
        [all_dates, all_clusters],
        names=["date_received", "cluster_id"],
    )

    series = (
        daily.set_index(["date_received", "cluster_id"])
        .reindex(grid, fill_value=0)
        .reset_index()
    )

    rows = []

    for cid, g in series.groupby("cluster_id"):
        g = g.sort_values("date_received").copy()
        s = g["count"].astype(float)

        g["rolling_7d"] = s.rolling(7, min_periods=7).sum()
        g["previous_28d_mean_daily"] = s.shift(7).rolling(28, min_periods=14).mean()
        g["expected_7d"] = g["previous_28d_mean_daily"] * 7
        g["lift"] = g["rolling_7d"] / g["expected_7d"].replace(0, np.nan)
        g["z_score"] = (
            (g["rolling_7d"] - g["expected_7d"])
            / np.sqrt(g["expected_7d"].clip(lower=1))
        )

        recent = g.dropna(subset=["expected_7d"]).iloc[-1]
        current = float(recent["rolling_7d"])
        expected = float(recent["expected_7d"])
        lift = float(recent["lift"]) if pd.notna(recent["lift"]) else 0.0
        z = float(recent["z_score"]) if pd.notna(recent["z_score"]) else 0.0

        alert = (
            current >= MIN_CURRENT_COUNT
            and lift >= MIN_LIFT
            and z >= MIN_Z
        )

        rows.append({
            "cluster_id": int(cid),
            "candidate_label": label_map.get(int(cid), ""),
            "current_7d_count": int(current),
            "expected_7d_count": round(expected, 2),
            "lift": round(lift, 3),
            "z_score": round(z, 3),
            "alert": bool(alert),
            "period_end": recent["date_received"].strftime("%Y-%m-%d"),
        })

    result = pd.DataFrame(rows).sort_values(
        ["alert", "lift", "current_7d_count"],
        ascending=[False, False, False],
    )

    result.to_csv(
        REPORTS / "cfpb_issue_trend_scores.csv",
        index=False,
    )

    print("=== CFPB INCIDENT TREND ANALYSIS ===")
    print(f"Clusters analyzed: {len(result)}")
    print(
        f"Alert thresholds: current_7d >= {MIN_CURRENT_COUNT}, "
        f"lift >= {MIN_LIFT}, z >= {MIN_Z}"
    )

    alerts = result[result["alert"]]
    print(f"Potential emerging issues: {len(alerts)}")

    if not alerts.empty:
        print("\nPotential emerging issues:")
        for _, row in alerts.head(15).iterrows():
            print(
                f"  Cluster {int(row.cluster_id):>3} | "
                f"7d={int(row.current_7d_count):>3} | "
                f"expected={row.expected_7d_count:>5.1f} | "
                f"lift={row.lift:>4.2f}x | "
                f"z={row.z_score:>5.2f} | "
                f"{row.candidate_label or '[no label]'}"
            )
    else:
        print("\nNo clusters crossed the current alert thresholds.")

    print(f"\nOutput: {REPORTS / 'cfpb_issue_trend_scores.csv'}")
    print("\nBRICK 8 TREND ANALYSIS: PASS")

if __name__ == "__main__":
    main()
