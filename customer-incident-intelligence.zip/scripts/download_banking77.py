from __future__ import annotations

import csv
import hashlib
import urllib.request
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
RAW_DIR = ROOT / "data" / "raw"
RAW_DIR.mkdir(parents=True, exist_ok=True)

FILES = {
    "train.csv": (
        "https://raw.githubusercontent.com/PolyAI-LDN/task-specific-datasets/"
        "master/banking_data/train.csv",
        "b06e26ac675513959a63135f11b94ea7786ed02da65db93a5650d8838cbc664b",
        10003,
    ),
    "test.csv": (
        "https://raw.githubusercontent.com/PolyAI-LDN/task-specific-datasets/"
        "master/banking_data/test.csv",
        "d12d6e3bc4c3103966ae786dc435913c0c563dfa328f5a3646d0e62cfeeb474b",
        3080,
    ),
}

def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()

def main() -> None:
    for filename, (url, expected_sha, expected_rows) in FILES.items():
        destination = RAW_DIR / filename
        print(f"Downloading {filename} ...")
        urllib.request.urlretrieve(url, destination)

        actual_sha = sha256(destination)
        if actual_sha != expected_sha:
            raise RuntimeError(
                f"Checksum mismatch for {filename}: "
                f"expected {expected_sha}, got {actual_sha}"
            )

        with destination.open("r", encoding="utf-8", newline="") as f:
            rows = list(csv.DictReader(f))

        if len(rows) != expected_rows:
            raise RuntimeError(
                f"Unexpected row count for {filename}: "
                f"expected {expected_rows}, got {len(rows)}"
            )

        print(f"  PASS | {len(rows):,} rows | SHA-256 verified")

    print("\nBRICK 2 DOWNLOAD: PASS")
    print(f"Raw data location: {RAW_DIR}")

if __name__ == "__main__":
    main()
