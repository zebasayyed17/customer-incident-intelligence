from __future__ import annotations

import hashlib
import urllib.request
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "data" / "cfpb_raw"
OUT.mkdir(parents=True, exist_ok=True)

ARCHIVES = {
    "2026-05": "https://files.consumerfinance.gov/f/documents/CCDB_Export_18_May_2026.zip",
    "2026-06": "https://files.consumerfinance.gov/f/documents/CCDB_Export_19_June_2026.zip",
    "2026-07": "https://files.consumerfinance.gov/f/documents/CCDB_Export_20_July_2026.zip",
    "2026-08": "https://files.consumerfinance.gov/f/documents/CCDB_Export_21_August_2026.zip",
}

def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()

def main() -> None:
    print("=== CFPB ARCHIVE DOWNLOAD ===")
    print("Source: CFPB Consumer Complaint Database narrative archive")
    print("Coverage: May 2026 through August 14, 2026")

    for month, url in ARCHIVES.items():
        destination = OUT / f"CCDB_{month}.zip"

        if destination.exists():
            print(f"\n{month}: already downloaded")
            print(f"  SHA-256: {sha256(destination)}")
            continue

        print(f"\nDownloading {month} ...")
        urllib.request.urlretrieve(url, destination)
        print(f"  Saved: {destination}")
        print(f"  SHA-256: {sha256(destination)}")

    print("\nBRICK 7 DOWNLOAD: PASS")

if __name__ == "__main__":
    main()
