from __future__ import annotations

import json
from collections import Counter, defaultdict
from pathlib import Path

import numpy as np
from sklearn.metrics import adjusted_rand_score, normalized_mutual_info_score

ROOT = Path(__file__).resolve().parents[1]
PROCESSED = ROOT / "data" / "processed"
REPORTS = ROOT / "data" / "reports"

def main() -> None:
    cluster_ids = np.load(PROCESSED / "train_cluster_ids.npy")
    labels = np.array(
        json.loads(
            (PROCESSED / "train_labels.json").read_text(encoding="utf-8")
        )
    )

    non_noise = cluster_ids != -1

    if non_noise.sum() == 0:
        raise RuntimeError("HDBSCAN produced no non-noise clusters.")

    ari = adjusted_rand_score(labels[non_noise], cluster_ids[non_noise])
    nmi = normalized_mutual_info_score(labels[non_noise], cluster_ids[non_noise])

    cluster_to_labels: dict[int, Counter] = defaultdict(Counter)
    for cluster_id, label in zip(cluster_ids[non_noise], labels[non_noise]):
        cluster_to_labels[int(cluster_id)][str(label)] += 1

    purity_values = []
    for counts in cluster_to_labels.values():
        purity_values.append(max(counts.values()) / sum(counts.values()))

    mean_purity = float(np.mean(purity_values)) if purity_values else 0.0

    report = {
        "adjusted_rand_index_non_noise": round(float(ari), 4),
        "normalized_mutual_information_non_noise": round(float(nmi), 4),
        "mean_cluster_purity_non_noise": round(mean_purity, 4),
        "non_noise_rows": int(non_noise.sum()),
        "noise_rows": int((~non_noise).sum()),
        "cluster_count": int(len(set(cluster_ids) - {-1})),
    }

    (REPORTS / "cluster_quality.json").write_text(
        json.dumps(report, indent=2),
        encoding="utf-8",
    )

    print("=== CLUSTER QUALITY DIAGNOSTIC ===")
    print(f"Clusters:              {report['cluster_count']}")
    print(f"Non-noise rows:         {report['non_noise_rows']:,}")
    print(f"Noise rows:             {report['noise_rows']:,}")
    print(f"ARI:                    {ari:.4f}")
    print(f"NMI:                    {nmi:.4f}")
    print(f"Mean cluster purity:    {mean_purity:.4f}")
    print("\nImportant: labels were NOT used to create clusters.")
    print("They are only used here after clustering to measure quality.")

    # We deliberately avoid a hard numerical "pass" threshold here.
    # Unsupervised clustering quality is highly dependent on cluster granularity.
    print("\nBRICK 5 QUALITY DIAGNOSTIC: COMPLETE")

if __name__ == "__main__":
    main()
