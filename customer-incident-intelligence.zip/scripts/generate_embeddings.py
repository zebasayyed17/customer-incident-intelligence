from __future__ import annotations

import csv
import json
import time
from pathlib import Path

import numpy as np
import torch
from sentence_transformers import SentenceTransformer

ROOT = Path(__file__).resolve().parents[1]
RAW = ROOT / "data" / "raw"
PROCESSED = ROOT / "data" / "processed"
REPORTS = ROOT / "data" / "reports"
PROCESSED.mkdir(parents=True, exist_ok=True)
REPORTS.mkdir(parents=True, exist_ok=True)

MODEL_NAME = "sentence-transformers/all-MiniLM-L6-v2"
BATCH_SIZE = 64 if torch.cuda.is_available() else 32

def load_csv(path: Path) -> tuple[list[str], list[str]]:
    texts: list[str] = []
    labels: list[str] = []
    with path.open("r", encoding="utf-8", newline="") as f:
        for row in csv.DictReader(f):
            texts.append(row["text"])
            labels.append(row["category"])
    return texts, labels

def main() -> None:
    device = "cuda" if torch.cuda.is_available() else "cpu"
    print(f"Model: {MODEL_NAME}")
    print(f"Device: {device}")
    if device == "cuda":
        print(f"GPU: {torch.cuda.get_device_name(0)}")
    print(f"Batch size: {BATCH_SIZE}")

    train_texts, train_labels = load_csv(RAW / "train.csv")
    eval_texts, eval_labels = load_csv(PROCESSED / "evaluation_test_deduped.csv")

    model = SentenceTransformer(MODEL_NAME, device=device)

    start = time.perf_counter()
    train_embeddings = model.encode(
        train_texts,
        batch_size=BATCH_SIZE,
        show_progress_bar=True,
        normalize_embeddings=True,
        convert_to_numpy=True,
    )
    train_seconds = time.perf_counter() - start

    start = time.perf_counter()
    eval_embeddings = model.encode(
        eval_texts,
        batch_size=BATCH_SIZE,
        show_progress_bar=True,
        normalize_embeddings=True,
        convert_to_numpy=True,
    )
    eval_seconds = time.perf_counter() - start

    train_embeddings = np.asarray(train_embeddings, dtype=np.float32)
    eval_embeddings = np.asarray(eval_embeddings, dtype=np.float32)

    np.save(PROCESSED / "train_embeddings.npy", train_embeddings)
    np.save(PROCESSED / "evaluation_embeddings.npy", eval_embeddings)

    (PROCESSED / "train_labels.json").write_text(
        json.dumps(train_labels, ensure_ascii=False),
        encoding="utf-8",
    )
    (PROCESSED / "evaluation_labels.json").write_text(
        json.dumps(eval_labels, ensure_ascii=False),
        encoding="utf-8",
    )

    report = {
        "model": MODEL_NAME,
        "device": device,
        "train_rows": len(train_texts),
        "eval_rows": len(eval_texts),
        "embedding_dimensions": int(train_embeddings.shape[1]),
        "train_seconds": round(train_seconds, 3),
        "eval_seconds": round(eval_seconds, 3),
        "train_rows_per_second": round(len(train_texts) / train_seconds, 2),
        "eval_rows_per_second": round(len(eval_texts) / eval_seconds, 2),
        "train_shape": list(train_embeddings.shape),
        "eval_shape": list(eval_embeddings.shape),
        "embeddings_normalized": True,
    }

    (REPORTS / "embedding_generation.json").write_text(
        json.dumps(report, indent=2),
        encoding="utf-8",
    )

    print("\n=== EMBEDDING GENERATION ===")
    print(f"Train embeddings: {train_embeddings.shape}")
    print(f"Eval embeddings:  {eval_embeddings.shape}")
    print(f"Train time:       {train_seconds:.2f}s")
    print(f"Eval time:        {eval_seconds:.2f}s")
    print(f"Train throughput: {len(train_texts) / train_seconds:.1f} texts/s")
    print("\nBRICK 4 EMBEDDINGS: PASS")

if __name__ == "__main__":
    main()
