from __future__ import annotations

import csv
import json
from collections import Counter, defaultdict
from pathlib import Path

import numpy as np

ROOT = Path(__file__).resolve().parents[1]
RAW = ROOT / "data" / "raw"
PROCESSED = ROOT / "data" / "processed"
REPORTS = ROOT / "data" / "reports"

def main() -> None:
    with (RAW / "train.csv").open("r", encoding="utf-8", newline="") as f:
        rows = list(csv.DictReader(f))

    cluster_ids = np.load(PROCESSED / "train_cluster_ids.npy")
    if len(rows) != len(cluster_ids):
        raise RuntimeError("Cluster IDs and training rows have different lengths.")

    groups: dict[int, list[int]] = defaultdict(list)
    for idx, cid in enumerate(cluster_ids):
        if int(cid) != -1:
            groups[int(cid)].append(idx)

    cluster_summaries = []

    for cid, indices in sorted(groups.items(), key=lambda item: len(item[1]), reverse=True):
        label_counts = Counter(rows[i]["category"] for i in indices)
        examples = [rows[i]["text"] for i in indices[:5]]

        cluster_summaries.append({
            "cluster_id": cid,
            "size": len(indices),
            "dominant_known_intent_for_diagnostic_only": label_counts.most_common(1)[0][0],
            "dominant_intent_share_for_diagnostic_only": round(
                label_counts.most_common(1)[0][1] / len(indices), 4
            ),
            "top_known_intents_for_diagnostic_only": label_counts.most_common(5),
            "examples": examples,
        })

    (REPORTS / "cluster_examples.json").write_text(
        json.dumps(cluster_summaries[:50], indent=2, ensure_ascii=False),
        encoding="utf-8",
    )

    print("=== CLUSTER EXAMPLES ===")
    for item in cluster_summaries[:10]:
        print(f"\nCluster {item['cluster_id']} | {item['size']} rows")
        print(
            "  Diagnostic dominant intent: "
            f"{item['dominant_known_intent_for_diagnostic_only']}"
        )
        for text in item["examples"][:3]:
            print(f"  - {text}")

    print("\nBRICK 5 EXAMPLE INSPECTION: PASS")

if __name__ == "__main__":
    main()
