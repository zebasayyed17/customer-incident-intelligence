from __future__ import annotations

import csv
from collections import defaultdict
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
RAW_DIR = ROOT / "data" / "raw"

def load(path: Path) -> list[dict[str, str]]:
    with path.open("r", encoding="utf-8", newline="") as f:
        return list(csv.DictReader(f))

def main() -> None:
    train = load(RAW_DIR / "train.csv")

    by_category: dict[str, list[str]] = defaultdict(list)
    for row in train:
        by_category[row["category"]].append(row["text"])

    print("=== REPRESENTATIVE TRAINING EXAMPLES ===")
    for category in sorted(by_category)[:10]:
        print(f"\n[{category}]")
        for text in by_category[category][:3]:
            print(f"  - {text}")

    print("\nBRICK 3 EXAMPLE INSPECTION: PASS")

if __name__ == "__main__":
    main()
