from __future__ import annotations

import csv
import json
import statistics
from collections import Counter
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
RAW_DIR = ROOT / "data" / "raw"
REPORT_DIR = ROOT / "data" / "reports"
REPORT_DIR.mkdir(parents=True, exist_ok=True)

FILES = ("train.csv", "test.csv")

def load_rows(path: Path) -> list[dict[str, str]]:
    with path.open("r", encoding="utf-8", newline="") as f:
        return list(csv.DictReader(f))

def clean_text(text: str) -> str:
    return " ".join((text or "").split()).strip().lower()

def describe(rows: list[dict[str, str]]) -> dict:
    lengths = [len(row["text"]) for row in rows]
    word_counts = [len(row["text"].split()) for row in rows]
    categories = Counter(row["category"] for row in rows)

    return {
        "rows": len(rows),
        "unique_texts": len({clean_text(r["text"]) for r in rows}),
        "duplicate_texts": len(rows) - len({clean_text(r["text"]) for r in rows}),
        "category_count": len(categories),
        "min_chars": min(lengths),
        "max_chars": max(lengths),
        "mean_chars": round(statistics.mean(lengths), 2),
        "median_chars": round(statistics.median(lengths), 2),
        "mean_words": round(statistics.mean(word_counts), 2),
        "median_words": round(statistics.median(word_counts), 2),
        "min_words": min(word_counts),
        "max_words": max(word_counts),
        "top_categories": categories.most_common(10),
        "category_counts": dict(sorted(categories.items())),
    }

def main() -> None:
    train_path = RAW_DIR / "train.csv"
    test_path = RAW_DIR / "test.csv"

    for path in (train_path, test_path):
        if not path.exists():
            raise FileNotFoundError(f"Missing dataset file: {path}")

    train = load_rows(train_path)
    test = load_rows(test_path)

    train_clean = {clean_text(r["text"]) for r in train}
    test_clean = {clean_text(r["text"]) for r in test}
    overlap = sorted(train_clean & test_clean)

    report = {
        "dataset": "BANKING77",
        "train": describe(train),
        "test": describe(test),
        "cross_split_exact_text_overlap": {
            "count": len(overlap),
            "examples": overlap[:20],
        },
    }

    (REPORT_DIR / "dataset_profile.json").write_text(
        json.dumps(report, indent=2, ensure_ascii=False),
        encoding="utf-8",
    )

    print("=== BANKING77 PROFILE ===")
    print(f"Train rows: {len(train):,}")
    print(f"Test rows:  {len(test):,}")
    print(f"Categories: {len(report['train']['category_counts'])}")
    print(f"Train duplicate rows: {report['train']['duplicate_texts']}")
    print(f"Test duplicate rows:  {report['test']['duplicate_texts']}")
    print(
        "Exact train/test text overlap: "
        f"{len(overlap)}"
    )

    print("\nTop 10 training categories:")
    for category, count in report["train"]["top_categories"]:
        print(f"  {category:<42} {count:>4}")

    print("\nText length:")
    print(
        f"  Characters: mean={report['train']['mean_chars']}, "
        f"median={report['train']['median_chars']}, "
        f"range={report['train']['min_chars']}-{report['train']['max_chars']}"
    )
    print(
        f"  Words:      mean={report['train']['mean_words']}, "
        f"median={report['train']['median_words']}, "
        f"range={report['train']['min_words']}-{report['train']['max_words']}"
    )

    if overlap:
        print("\nWARNING: exact duplicate text exists across train/test.")
        for text in overlap[:10]:
            print(f"  - {text}")
        raise SystemExit(2)

    print("\nNo exact train/test text overlap detected.")
    print(f"Report written to: {REPORT_DIR / 'dataset_profile.json'}")
    print("\nBRICK 3 PROFILE: PASS")

if __name__ == "__main__":
    main()
