<#
Publish Customer Incident Intelligence to GitHub.

Usage:
  .\scripts\publish_to_github.ps1

The script:
- verifies that the repository is cleanly structured
- installs GitHub CLI through winget if needed
- asks you to authenticate with GitHub if necessary
- creates a public repository named customer-incident-intelligence
- initializes git if needed
- commits the project
- pushes the default branch
#>
$ErrorActionPreference = 'Stop'
$RepoRoot = Split-Path -Parent $PSScriptRoot
Set-Location $RepoRoot

Write-Host "Customer Incident Intelligence -> GitHub" -ForegroundColor Cyan
Write-Host "Repository root: $RepoRoot" -ForegroundColor Gray

if (-not (Get-Command git.exe -ErrorAction SilentlyContinue)) {
    throw "Git is not installed. Install Git for Windows, then rerun this script."
}

$gh = Get-Command gh.exe -ErrorAction SilentlyContinue
if (-not $gh) {
    $winget = Get-Command winget.exe -ErrorAction SilentlyContinue
    if (-not $winget) {
        throw "GitHub CLI is missing and winget.exe was not found. Install GitHub CLI, then rerun."
    }
    Write-Host "Installing GitHub CLI..." -ForegroundColor Yellow
    winget install --id GitHub.cli --source winget --accept-source-agreements --accept-package-agreements
    $gh = Get-Command gh.exe -ErrorAction SilentlyContinue
    if (-not $gh) { throw "GitHub CLI installation completed, but gh.exe is not available in this shell. Open a new PowerShell window and rerun." }
}

$auth = & gh auth status 2>&1
if ($LASTEXITCODE -ne 0) {
    Write-Host "GitHub authentication is required." -ForegroundColor Yellow
    & gh auth login
}

if (-not (Test-Path (Join-Path $RepoRoot '.git'))) {
    git init | Out-Host
}

$branch = (git branch --show-current).Trim()
if (-not $branch) {
    git checkout -b main | Out-Host
} elseif ($branch -ne 'main') {
    git branch -M main | Out-Host
}

git add .
git status --short | Out-Host
$hasHead = $true
try { git rev-parse --verify HEAD *> $null } catch { $hasHead = $false }
if (-not $hasHead) {
    git commit -m "Initial release: Customer Incident Intelligence" | Out-Host
} else {
    git commit -m "Polish repository for release" | Out-Host
}

Write-Host "Creating/pushing public GitHub repository..." -ForegroundColor Cyan
& gh repo create customer-incident-intelligence --public --source . --remote origin --push
if ($LASTEXITCODE -ne 0) { throw "GitHub publish failed." }

$repoUrl = (& gh repo view --json url --jq '.url').Trim()
Write-Host "Published: $repoUrl" -ForegroundColor Green
