$ErrorActionPreference = "Stop"
$ProjectRoot = Split-Path -Parent $PSScriptRoot
Set-Location $ProjectRoot
$Python = Join-Path $ProjectRoot ".venv\Scripts\python.exe"
if (-not (Test-Path $Python)) { throw "Python venv not found: $Python" }
Write-Host "Checking Web UI dependencies..."
& $Python -m pip install -r (Join-Path $ProjectRoot "requirements-add.txt") --disable-pip-version-check --quiet
Write-Host "Starting Customer Incident Intelligence Web UI on http://127.0.0.1:8000 ..."
& $Python -m uvicorn backend.app.main:app --host 127.0.0.1 --port 8000
