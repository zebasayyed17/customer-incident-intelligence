"""Brick 1: verify pretrained NLP inference end-to-end."""

from __future__ import annotations

import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]

EMBEDDING_MODEL = "sentence-transformers/all-MiniLM-L6-v2"
SENTIMENT_MODEL = "j-hartmann/sentiment-roberta-large-english-3-classes"

SAMPLES = [
    "The ATM charged my account but did not give me any cash.",
    "My card still has not arrived after two weeks.",
    "The transfer went through successfully. Thank you.",
]


def main() -> int:
    try:
        from sentence_transformers import SentenceTransformer
        from transformers import pipeline
    except Exception as exc:
        print(f"DEPENDENCY ERROR: {exc}")
        print("Install the project requirements before running this test.")
        return 2

    print(f"Loading embedding model: {EMBEDDING_MODEL}")
    embedding_model = SentenceTransformer(EMBEDDING_MODEL)

    print(f"Loading sentiment model: {SENTIMENT_MODEL}")
    sentiment_model = pipeline(
        "sentiment-analysis",
        model=SENTIMENT_MODEL,
        tokenizer=SENTIMENT_MODEL,
    )

    print("\n=== Embedding test ===")
    embeddings = embedding_model.encode(
        SAMPLES,
        normalize_embeddings=True,
        show_progress_bar=False,
    )

    print(f"Embedding matrix shape: {embeddings.shape}")
    if embeddings.shape[0] != len(SAMPLES) or embeddings.shape[1] != 384:
        print("FAIL: unexpected embedding shape")
        return 1

    print("Embedding test: PASS")

    print("\n=== Semantic similarity test ===")
    # Cosine similarity because embeddings are normalized.
    similarity = embeddings @ embeddings.T
    print(f"ATM vs card-arrival similarity: {similarity[0, 1]:.4f}")
    print(f"ATM vs transfer-success similarity: {similarity[0, 2]:.4f}")
    print("Similarity test: PASS")

    print("\n=== Sentiment test ===")
    predictions = sentiment_model(SAMPLES)
    for text, prediction in zip(SAMPLES, predictions):
        print(f"{prediction['label']:>9} | {prediction['score']:.4f} | {text}")

    if len(predictions) != len(SAMPLES):
        print("FAIL: sentiment model did not return one prediction per input")
        return 1

    print("Sentiment test: PASS")
    print("\nBRICK 1: PASS")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
