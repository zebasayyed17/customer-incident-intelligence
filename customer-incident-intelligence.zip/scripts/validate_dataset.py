from __future__ import annotations

import csv
from collections import Counter
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
RAW_DIR = ROOT / "data" / "raw"

EXPECTED = {
    "train.csv": 10003,
    "test.csv": 3080,
}

def validate_file(path: Path, expected_rows: int) -> tuple[list[str], Counter[str], int]:
    with path.open("r", encoding="utf-8", newline="") as f:
        reader = csv.DictReader(f)
        if reader.fieldnames != ["text", "category"]:
            raise RuntimeError(
                f"{path.name}: expected columns ['text', 'category']; "
                f"found {reader.fieldnames}"
            )

        rows = list(reader)

    if len(rows) != expected_rows:
        raise RuntimeError(
            f"{path.name}: expected {expected_rows} rows, got {len(rows)}"
        )

    missing_text = sum(not (row["text"] or "").strip() for row in rows)
    missing_category = sum(not (row["category"] or "").strip() for row in rows)

    if missing_text or missing_category:
        raise RuntimeError(
            f"{path.name}: missing text={missing_text}, "
            f"missing category={missing_category}"
        )

    categories = Counter(row["category"].strip() for row in rows)
    duplicates = len(rows) - len({row["text"].strip() for row in rows})

    if len(categories) != 77:
        raise RuntimeError(
            f"{path.name}: expected 77 categories, got {len(categories)}"
        )

    return rows[0].keys(), categories, duplicates

def main() -> None:
    if not RAW_DIR.exists():
        raise RuntimeError(
            "Raw dataset directory does not exist. "
            "Run download_banking77.py first."
        )

    combined_categories: set[str] = set()

    for filename, expected_rows in EXPECTED.items():
        path = RAW_DIR / filename
        if not path.exists():
            raise RuntimeError(f"Missing file: {path}")

        _, categories, duplicates = validate_file(path, expected_rows)
        combined_categories.update(categories)

        print(f"\n{filename}")
        print(f"  Rows:              {expected_rows:,}")
        print(f"  Categories:        {len(categories)}")
        print(f"  Duplicate texts:   {duplicates}")
        print(f"  Empty text/label:  0")
        print(f"  Validation:        PASS")

    if len(combined_categories) != 77:
        raise RuntimeError(
            f"Combined dataset should contain 77 categories; "
            f"found {len(combined_categories)}"
        )

    print("\nBRICK 2 VALIDATION: PASS")
    print("Dataset structure is ready for preprocessing and analysis.")

if __name__ == "__main__":
    main()
