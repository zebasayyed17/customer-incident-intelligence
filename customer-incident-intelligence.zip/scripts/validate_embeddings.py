from __future__ import annotations

import json
from pathlib import Path

import numpy as np
from sklearn.metrics import accuracy_score
from sklearn.preprocessing import normalize

ROOT = Path(__file__).resolve().parents[1]
PROCESSED = ROOT / "data" / "processed"
REPORTS = ROOT / "data" / "reports"

def cosine_centroid_prediction(
    train_embeddings: np.ndarray,
    train_labels: list[str],
    eval_embeddings: np.ndarray,
) -> tuple[np.ndarray, float, float]:
    labels = np.array(train_labels)
    classes = np.unique(labels)

    centroids = []
    for cls in classes:
        centroid = train_embeddings[labels == cls].mean(axis=0)
        centroids.append(centroid)

    centroids = normalize(np.asarray(centroids, dtype=np.float32))
    eval_embeddings = normalize(eval_embeddings.astype(np.float32))

    # Chunked matrix multiplication keeps RAM usage reasonable.
    predictions: list[str] = []
    max_scores: list[float] = []
    chunk_size = 512

    for start in range(0, len(eval_embeddings), chunk_size):
        chunk = eval_embeddings[start:start + chunk_size]
        scores = chunk @ centroids.T
        best = np.argmax(scores, axis=1)
        predictions.extend(classes[best].tolist())
        max_scores.extend(scores[np.arange(len(chunk)), best].tolist())

    return np.array(predictions), accuracy_score(
        json.loads((PROCESSED / "evaluation_labels.json").read_text(encoding="utf-8")),
        predictions,
    ), float(np.mean(max_scores))

def main() -> None:
    train_embeddings = np.load(PROCESSED / "train_embeddings.npy")
    eval_embeddings = np.load(PROCESSED / "evaluation_embeddings.npy")
    train_labels = json.loads(
        (PROCESSED / "train_labels.json").read_text(encoding="utf-8")
    )
    eval_labels = json.loads(
        (PROCESSED / "evaluation_labels.json").read_text(encoding="utf-8")
    )

    if train_embeddings.shape[1] != 384:
        raise RuntimeError(f"Expected 384 dimensions, got {train_embeddings.shape[1]}")
    if eval_embeddings.shape[1] != 384:
        raise RuntimeError(f"Expected 384 dimensions, got {eval_embeddings.shape[1]}")

    predictions, centroid_accuracy, mean_confidence = cosine_centroid_prediction(
        train_embeddings,
        train_labels,
        eval_embeddings,
    )

    correct = predictions == np.array(eval_labels)
    results = {
        "model": "sentence-transformers/all-MiniLM-L6-v2",
        "evaluation_rows": len(eval_labels),
        "classes": len(set(train_labels)),
        "centroid_accuracy": round(float(centroid_accuracy), 4),
        "mean_best_centroid_cosine": round(mean_confidence, 4),
        "correct_predictions": int(correct.sum()),
        "incorrect_predictions": int((~correct).sum()),
    }

    (REPORTS / "embedding_quality.json").write_text(
        json.dumps(results, indent=2),
        encoding="utf-8",
    )

    print("=== EMBEDDING QUALITY CHECK ===")
    print(f"Evaluation rows:             {len(eval_labels):,}")
    print(f"Intent classes:              {len(set(train_labels))}")
    print(f"Centroid classification:     {centroid_accuracy:.4f}")
    print(f"Mean best-centroid cosine:   {mean_confidence:.4f}")
    print(f"Correct:                     {int(correct.sum()):,}")
    print(f"Incorrect:                   {int((~correct).sum()):,}")

    print("\nThis is a diagnostic probe, not our final ML classifier.")
    print("It tests whether MiniLM embeddings separate the 77 intents by meaning.")

    if centroid_accuracy < 0.50:
        raise RuntimeError(
            "Embedding diagnostic accuracy is unexpectedly low (< 0.50). "
            "Stop and inspect embeddings before building clustering."
        )

    print("\nBRICK 4 QUALITY CHECK: PASS")

if __name__ == "__main__":
    main()
