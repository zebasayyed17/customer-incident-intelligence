"""Check that this machine is ready for Brick 1."""

from __future__ import annotations

import sys


def main() -> int:
    print(f"Python: {sys.version.split()[0]}")

    if sys.version_info >= (3, 13):
        print("WARNING: Python 3.13+ is not the target Windows environment for this project.")
        print("Use Python 3.12 for the most predictable PyTorch/Transformers setup on Windows.")

    try:
        import torch
        print(f"PyTorch: {torch.__version__}")
        print(f"CUDA available: {torch.cuda.is_available()}")
        if torch.cuda.is_available():
            print(f"GPU: {torch.cuda.get_device_name(0)}")
    except Exception as exc:
        print(f"PyTorch check failed: {exc}")

    for package in ("transformers", "sentence_transformers", "sklearn", "pandas", "fastapi"):
        try:
            module = __import__(package)
            print(f"{package}: OK ({getattr(module, '__version__', 'version unavailable')})")
        except Exception as exc:
            print(f"{package}: MISSING/ERROR ({exc})")

    return 0


if __name__ == "__main__":
    raise SystemExit(main())
