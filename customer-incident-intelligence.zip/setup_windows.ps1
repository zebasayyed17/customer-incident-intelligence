$ErrorActionPreference = "Stop"

Write-Host "=== Customer Incident Intelligence: Windows setup ===" -ForegroundColor Cyan
Write-Host ""

$py = Get-Command py -ErrorAction SilentlyContinue
if (-not $py) { throw "Python Launcher (py.exe) was not found. Install Python 3.12 first." }

$python312 = & py -3.12 --version 2>$null
if ($LASTEXITCODE -ne 0) { throw "Python 3.12 was not found. Install Python 3.12 before continuing." }

Write-Host "Using $python312" -ForegroundColor Green

if (-not (Test-Path ".venv")) {
    & py -3.12 -m venv .venv
}

$venvPython = Join-Path (Get-Location) ".venv\Scripts\python.exe"
if (-not (Test-Path $venvPython)) { throw "Virtual environment Python was not created: $venvPython" }

& $venvPython -m pip install --upgrade pip
& $venvPython -m pip install -r requirements.txt

Write-Host ""
Write-Host "Environment installed." -ForegroundColor Green
Write-Host "Run: .\.venv\Scripts\python.exe scripts\verify_environment.py"
Write-Host "Then run: .\.venv\Scripts\python.exe scripts\smoke_test.py"
Write-Host "Finally run: .\scripts\run_webui.ps1"
Write-Host ""
Write-Host "If torch reports CUDA=False on an NVIDIA machine, install the matching Windows CUDA PyTorch build from the official PyTorch selector and rerun verification." -ForegroundColor Yellow
